package com.example.expensetracker.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.expensetracker.data.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val settings = SettingsRepository(context.applicationContext)
            CoroutineScope(Dispatchers.IO).launch {
                if (settings.reminderEnabled.first()) {
                    val hour = settings.reminderHour.first()
                    val minute = settings.reminderMinute.first()
                    NotificationHelper.scheduleDaily(context.applicationContext, hour, minute)
                }
            }
        }
    }
}
