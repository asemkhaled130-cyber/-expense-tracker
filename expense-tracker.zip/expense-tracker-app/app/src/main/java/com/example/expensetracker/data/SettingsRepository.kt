package com.example.expensetracker.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "settings")

object Keys {
    val THEME = stringPreferencesKey("theme") // auto/light/dark
    val LANGUAGE = stringPreferencesKey("language") // ar/en
    val CURRENCY = stringPreferencesKey("currency")
    val ONBOARDING_SEEN = booleanPreferencesKey("onboarding_seen")

    val PIN_ENABLED = booleanPreferencesKey("pin_enabled")
    val PIN_HASH = stringPreferencesKey("pin_hash")
    val AUTO_LOCK_MIN = intPreferencesKey("auto_lock_min")
    val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")

    val SAVINGS_GOAL = stringPreferencesKey("savings_goal") // نخزنها كنص عشان نسمح بـ null بسهولة

    val REMINDER_ENABLED = booleanPreferencesKey("reminder_enabled")
    val REMINDER_HOUR = intPreferencesKey("reminder_hour")
    val REMINDER_MINUTE = intPreferencesKey("reminder_minute")

    val DRIVE_ACCOUNT_EMAIL = stringPreferencesKey("drive_account_email")
    val LAST_ACTIVE_TS = stringPreferencesKey("last_active_ts")
}

class SettingsRepository(private val context: Context) {
    val theme: Flow<String> = context.dataStore.data.map { it[Keys.THEME] ?: "auto" }
    val language: Flow<String> = context.dataStore.data.map { it[Keys.LANGUAGE] ?: "ar" }
    val currency: Flow<String> = context.dataStore.data.map { it[Keys.CURRENCY] ?: "جنيه" }
    val onboardingSeen: Flow<Boolean> = context.dataStore.data.map { it[Keys.ONBOARDING_SEEN] ?: false }

    val pinEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.PIN_ENABLED] ?: false }
    val pinHash: Flow<String> = context.dataStore.data.map { it[Keys.PIN_HASH] ?: "" }
    val autoLockMinutes: Flow<Int> = context.dataStore.data.map { it[Keys.AUTO_LOCK_MIN] ?: 5 }
    val biometricEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.BIOMETRIC_ENABLED] ?: false }

    val savingsGoal: Flow<Double?> = context.dataStore.data.map { it[Keys.SAVINGS_GOAL]?.toDoubleOrNull() }

    val reminderEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.REMINDER_ENABLED] ?: false }
    val reminderHour: Flow<Int> = context.dataStore.data.map { it[Keys.REMINDER_HOUR] ?: 20 }
    val reminderMinute: Flow<Int> = context.dataStore.data.map { it[Keys.REMINDER_MINUTE] ?: 0 }

    val driveAccountEmail: Flow<String?> = context.dataStore.data.map { it[Keys.DRIVE_ACCOUNT_EMAIL] }
    val lastActiveTs: Flow<Long> = context.dataStore.data.map { it[Keys.LAST_ACTIVE_TS]?.toLongOrNull() ?: 0L }

    suspend fun setTheme(v: String) = context.dataStore.edit { it[Keys.THEME] = v }
    suspend fun setLanguage(v: String) = context.dataStore.edit { it[Keys.LANGUAGE] = v }
    suspend fun setCurrency(v: String) = context.dataStore.edit { it[Keys.CURRENCY] = v }
    suspend fun setOnboardingSeen(v: Boolean) = context.dataStore.edit { it[Keys.ONBOARDING_SEEN] = v }

    suspend fun setPin(enabled: Boolean, hash: String) = context.dataStore.edit {
        it[Keys.PIN_ENABLED] = enabled; it[Keys.PIN_HASH] = hash
    }
    suspend fun setAutoLockMinutes(v: Int) = context.dataStore.edit { it[Keys.AUTO_LOCK_MIN] = v }
    suspend fun setBiometricEnabled(v: Boolean) = context.dataStore.edit { it[Keys.BIOMETRIC_ENABLED] = v }

    suspend fun setSavingsGoal(v: Double?) = context.dataStore.edit {
        if (v == null) it.remove(Keys.SAVINGS_GOAL) else it[Keys.SAVINGS_GOAL] = v.toString()
    }

    suspend fun setReminder(enabled: Boolean, hour: Int, minute: Int) = context.dataStore.edit {
        it[Keys.REMINDER_ENABLED] = enabled; it[Keys.REMINDER_HOUR] = hour; it[Keys.REMINDER_MINUTE] = minute
    }

    suspend fun setDriveAccountEmail(email: String?) = context.dataStore.edit {
        if (email == null) it.remove(Keys.DRIVE_ACCOUNT_EMAIL) else it[Keys.DRIVE_ACCOUNT_EMAIL] = email
    }

    suspend fun markActive() = context.dataStore.edit { it[Keys.LAST_ACTIVE_TS] = System.currentTimeMillis().toString() }

    suspend fun snapshot(): Map<String, Any?> {
        val prefs = context.dataStore.data.first()
        return prefs.asMap().mapKeys { it.key.name }
    }
}
