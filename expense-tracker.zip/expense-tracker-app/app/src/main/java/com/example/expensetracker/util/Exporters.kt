package com.example.expensetracker.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

object Exporters {

    /** يكتب صفوف بيانات كملف CSV بترميز UTF-8 مع BOM (يفتح بشكل صحيح في Excel مع دعم العربي) */
    fun exportCsv(context: Context, rows: List<List<String>>, fileName: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, fileName)
        FileOutputStream(file).use { fos ->
            fos.write(0xEF); fos.write(0xBB); fos.write(0xBF) // BOM
            rows.forEach { row ->
                val line = row.joinToString(",") { cell ->
                    val safe = cell.replace("\"", "\"\"")
                    "\"$safe\""
                } + "\n"
                fos.write(line.toByteArray(Charsets.UTF_8))
            }
        }
        return file
    }

    /** يكتب نص JSON خام كملف */
    fun exportJson(context: Context, jsonContent: String, fileName: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, fileName)
        file.writeText(jsonContent, Charsets.UTF_8)
        return file
    }

    /** يرسم تقرير بسيط كملف PDF (بدون أي مكتبة خارجية، باستخدام android.graphics.pdf المدمجة) */
    fun exportPdf(context: Context, title: String, rows: List<List<String>>, fileName: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, fileName)
        val document = PdfDocument()
        val pageWidth = 595; val pageHeight = 842 // A4 عند 72dpi تقريبًا
        val margin = 32f
        var pageNumber = 1
        var page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        var canvas: Canvas = page.canvas
        val titlePaint = Paint().apply { color = Color.BLACK; textSize = 16f; isFakeBoldText = true }
        val textPaint = Paint().apply { color = Color.DKGRAY; textSize = 10f }
        var y = margin + 20f
        canvas.drawText(title, margin, y, titlePaint)
        y += 26f
        rows.forEach { row ->
            if (y > pageHeight - margin) {
                document.finishPage(page)
                pageNumber++
                page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                canvas = page.canvas
                y = margin
            }
            val line = row.joinToString("  |  ")
            canvas.drawText(line, margin, y, textPaint)
            y += 16f
        }
        document.finishPage(page)
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    fun shareFile(context: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = mime
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, null))
    }

    fun shareText(context: Context, text: String) {
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, text)
        }
        context.startActivity(android.content.Intent.createChooser(intent, null))
    }
}
