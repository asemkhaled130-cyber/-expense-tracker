package com.example.expensetracker.ui.screens

import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.expensetracker.data.CurrencyEntity
import com.example.expensetracker.data.ItemLine
import com.example.expensetracker.data.WalletEntity
import com.example.expensetracker.model.Category
import com.example.expensetracker.ui.components.SectionLabel
import com.example.expensetracker.ui.icons.AppIcons
import com.example.expensetracker.util.OcrHelper
import kotlinx.coroutines.launch
import java.io.File

data class EntryFormResult(
    val type: String,
    val items: List<ItemLine>,
    val amount: Double,
    val note: String,
    val tags: List<String>,
    val walletId: String?,
    val currencyCode: String?,
    val splitCount: Int?,
    val images: List<String>
)

@Composable
fun EntryFormSheet(
    category: Category,
    existingType: String = "",
    existingItems: List<ItemLine> = emptyList(),
    existingAmount: Double = 0.0,
    existingNote: String = "",
    existingTags: List<String> = emptyList(),
    existingWallet: String? = null,
    existingCurrency: String? = null,
    existingSplit: Int? = null,
    existingImages: List<String> = emptyList(),
    wallets: List<WalletEntity>,
    currencies: List<CurrencyEntity>,
    checkAnomaly: suspend (Double) -> Double?,
    onSave: (EntryFormResult) -> Unit,
    onCancel: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var typeVal by remember { mutableStateOf(existingType) }
    var items by remember { mutableStateOf(existingItems.ifEmpty { listOf(ItemLine("", 0.0)) }) }
    var amountText by remember { mutableStateOf(if (existingAmount > 0) numToStr(existingAmount) else "") }
    var note by remember { mutableStateOf(existingNote) }
    var tagsText by remember { mutableStateOf(existingTags.joinToString(", ")) }
    var walletId by remember { mutableStateOf(existingWallet ?: wallets.firstOrNull()?.id) }
    var currencyCode by remember { mutableStateOf(existingCurrency) }
    var splitText by remember { mutableStateOf(existingSplit?.takeIf { it > 1 }?.toString() ?: "") }
    var images by remember { mutableStateOf(existingImages) }
    var typeMenuExpanded by remember { mutableStateOf(false) }
    var walletMenuExpanded by remember { mutableStateOf(false) }
    var currencyMenuExpanded by remember { mutableStateOf(false) }

    val validItems = items.filter { it.name.isNotBlank() && it.price > 0 }
    val itemsSum = validItems.sumOf { it.price }
    if (itemsSum > 0) amountText = numToStr(itemsSum)

    // ---------- الكاميرا ----------
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success && pendingCameraUri != null) {
            images = images + pendingCameraUri.toString()
            if (!category.isIncome) {
                scope.launch {
                    val text = runCatching { OcrHelper.recognizeText(context, pendingCameraUri!!) }.getOrNull()
                    val guessed = text?.let { OcrHelper.guessAmount(it) }
                    if (guessed != null && itemsSum <= 0) amountText = numToStr(guessed)
                }
            }
        }
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        images = images + uris.map { it.toString() }
    }

    // ---------- الإدخال الصوتي ----------
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (spoken != null) {
            val numRegex = Regex("""\d+(?:[.,]\d+)?""")
            val found = numRegex.find(spoken)?.value?.replace(",", ".")
            if (found != null) amountText = found else if (typeVal.isBlank()) typeVal = spoken
        }
    }

    fun launchCamera() {
        val dir = File(context.cacheDir, "images").apply { mkdirs() }
        val file = File(dir, "receipt_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingCameraUri = uri
        cameraLauncher.launch(uri)
    }
    fun launchVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
        }
        runCatching { voiceLauncher.launch(intent) }
    }

    Column(Modifier.fillMaxWidth().padding(18.dp)) {
        // النوع
        if (category.typesRes.isNotEmpty()) {
            SectionLabel("النوع")
            val typeNames = category.typesRes.map { androidx.compose.ui.res.stringResource(it) }
            ExposedDropdownMenuBox(expanded = typeMenuExpanded, onExpandedChange = { typeMenuExpanded = it }) {
                OutlinedTextField(
                    value = typeVal, onValueChange = { typeVal = it }, readOnly = false,
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeMenuExpanded) }
                )
                DropdownMenu(expanded = typeMenuExpanded, onDismissRequest = { typeMenuExpanded = false }) {
                    typeNames.forEach { name ->
                        DropdownMenuItem(text = { Text(name) }, onClick = { typeVal = name; typeMenuExpanded = false })
                    }
                }
            }
        } else {
            SectionLabel(if (category.isIncome) "مصدر الدخل" else "العنوان / الوصف (اختياري)")
            OutlinedTextField(value = typeVal, onValueChange = { typeVal = it }, modifier = Modifier.fillMaxWidth())
        }

        if (!category.isIncome) {
            SectionLabel("تفاصيل المشتريات (اختياري)")
            items.forEachIndexed { idx, item ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = item.name, onValueChange = { v -> items = items.toMutableList().also { it[idx] = item.copy(name = v) } },
                        modifier = Modifier.weight(2f), placeholder = { Text("اسم الصنف") }, singleLine = true
                    )
                    OutlinedTextField(
                        value = if (item.price > 0) numToStr(item.price) else "",
                        onValueChange = { v -> items = items.toMutableList().also { it[idx] = item.copy(price = v.toDoubleOrNull() ?: 0.0) } },
                        modifier = Modifier.weight(1f), placeholder = { Text("السعر") }, singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    IconButton(onClick = { items = items.toMutableList().also { it.removeAt(idx) }.ifEmpty { listOf(ItemLine("", 0.0)) } }) {
                        Icon(Icons.Outlined.Close, contentDescription = null)
                    }
                }
            }
            TextButton(onClick = { items = items + ItemLine("", 0.0) }) { Text("+ إضافة صنف") }
        }

        SectionLabel("المبلغ الإجمالي")
        OutlinedTextField(
            value = amountText, onValueChange = { amountText = it }, modifier = Modifier.fillMaxWidth(),
            readOnly = itemsSum > 0, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )

        if (currencies.isNotEmpty()) {
            SectionLabel("العملة")
            val label = currencyCode ?: "الأساسية"
            ExposedDropdownMenuBox(expanded = currencyMenuExpanded, onExpandedChange = { currencyMenuExpanded = it }) {
                OutlinedTextField(
                    value = label, onValueChange = {}, readOnly = true,
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = currencyMenuExpanded) }
                )
                DropdownMenu(expanded = currencyMenuExpanded, onDismissRequest = { currencyMenuExpanded = false }) {
                    DropdownMenuItem(text = { Text("الأساسية") }, onClick = { currencyCode = null; currencyMenuExpanded = false })
                    currencies.forEach { c ->
                        DropdownMenuItem(text = { Text("${c.code} (سعرها ${c.rate})") }, onClick = { currencyCode = c.code; currencyMenuExpanded = false })
                    }
                }
            }
        }

        if (wallets.size > 1) {
            SectionLabel("المحفظة")
            val walletName = wallets.find { it.id == walletId }?.name ?: ""
            ExposedDropdownMenuBox(expanded = walletMenuExpanded, onExpandedChange = { walletMenuExpanded = it }) {
                OutlinedTextField(
                    value = walletName, onValueChange = {}, readOnly = true,
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = walletMenuExpanded) }
                )
                DropdownMenu(expanded = walletMenuExpanded, onDismissRequest = { walletMenuExpanded = false }) {
                    wallets.forEach { w ->
                        DropdownMenuItem(text = { Text(w.name) }, onClick = { walletId = w.id; walletMenuExpanded = false })
                    }
                }
            }
        }

        if (!category.isIncome) {
            SectionLabel("تقسيم المصروف على أكتر من شخص (اختياري)")
            OutlinedTextField(
                value = splitText, onValueChange = { splitText = it }, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("عدد الأشخاص") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }

        SectionLabel("وسوم (اختياري) — افصل بينها بفاصلة")
        OutlinedTextField(value = tagsText, onValueChange = { tagsText = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("مثال: شغل, سفر") })

        SectionLabel("ملاحظات")
        OutlinedTextField(value = note, onValueChange = { note = it }, modifier = Modifier.fillMaxWidth(), minLines = 2)

        SectionLabel("صورة الفاتورة")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { launchCamera() }) { Icon(AppIcons.Camera, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("كاميرا") }
            OutlinedButton(onClick = { galleryLauncher.launch("image/*") }) { Icon(AppIcons.Attach, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("إرفاق ملف") }
            if (!category.isIncome) {
                OutlinedButton(onClick = { launchVoice() }) { Icon(AppIcons.Mic, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("صوت") }
            }
        }
        if (images.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(images) { img ->
                    Row {
                        coil.compose.AsyncImage(
                            model = img,
                            contentDescription = null,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.height(56.dp).width(56.dp)
                                .clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                        )
                        IconButton(onClick = { images = images.filter { it != img } }) { Icon(Icons.Outlined.Close, contentDescription = null) }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        var anomalyAvg by remember { mutableStateOf<Double?>(null) }
        var pendingResult by remember { mutableStateOf<EntryFormResult?>(null) }

        if (anomalyAvg != null && pendingResult != null) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { anomalyAvg = null; pendingResult = null },
                title = { Text("مبلغ أعلى من المعتاد") },
                text = { Text("المبلغ أعلى من متوسط مصروفك المعتاد في هذا القسم (${numToStr(anomalyAvg!!)}) بكتير. تأكيد الحفظ؟") },
                confirmButton = {
                    TextButton(onClick = { onSave(pendingResult!!); anomalyAvg = null; pendingResult = null }) { Text("تأكيد") }
                },
                dismissButton = {
                    TextButton(onClick = { anomalyAvg = null; pendingResult = null }) { Text("إلغاء") }
                }
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount <= 0) return@Button
                    val tags = tagsText.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    val split = splitText.toIntOrNull()?.takeIf { it > 1 }
                    val result = EntryFormResult(typeVal, validItems, amount, note, tags, walletId, currencyCode, split, images)
                    if (!category.isIncome) {
                        scope.launch {
                            val avg = checkAnomaly(amount)
                            if (avg != null) { anomalyAvg = avg; pendingResult = result } else onSave(result)
                        }
                    } else onSave(result)
                },
                colors = ButtonDefaults.buttonColors(),
                modifier = Modifier.weight(1f)
            ) { Icon(AppIcons.Save, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("حفظ") }
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("إلغاء") }
        }
    }
}

private fun numToStr(n: Double): String = if (n == n.toLong().toDouble()) n.toLong().toString() else n.toString()
