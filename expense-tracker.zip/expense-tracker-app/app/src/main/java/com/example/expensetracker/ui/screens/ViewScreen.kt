package com.example.expensetracker.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetracker.data.ExpenseEntity
import com.example.expensetracker.data.IncomeEntity
import com.example.expensetracker.data.JsonUtil
import com.example.expensetracker.model.Categories
import com.example.expensetracker.model.Category
import com.example.expensetracker.ui.components.DateNavBar
import com.example.expensetracker.ui.components.TagChip
import com.example.expensetracker.ui.icons.AppIcons
import com.example.expensetracker.ui.theme.LocalAppColors
import com.example.expensetracker.util.formatDateShort
import com.example.expensetracker.util.parseDate
import com.example.expensetracker.util.todayStr
import com.example.expensetracker.util.weekdayName
import com.example.expensetracker.viewmodel.AppViewModel

data class ViewCategoryGroup(val category: Category, val total: Double, val expenses: List<ExpenseEntity>, val income: List<IncomeEntity>)

@Composable
fun ViewScreen(vm: AppViewModel, lang: String) {
    val c = LocalAppColors.current
    val date by vm.viewDate.collectAsState()
    val expenses by vm.viewExpenses.collectAsState()
    val income by vm.viewIncome.collectAsState()
    val categories by vm.categories.collectAsState()

    val expenseTotal = expenses.sumOf { it.amount }
    val incomeTotal = income.sumOf { it.amount }

    val groups = remember(expenses, income, categories) {
        val byCat = expenses.groupBy { it.categoryId }
        val list = mutableListOf(
            ViewCategoryGroup(Categories.INCOME, incomeTotal, emptyList(), income)
        )
        list += categories.map { cat ->
            val list2 = byCat[cat.id] ?: emptyList()
            ViewCategoryGroup(cat, list2.sumOf { it.amount }, list2, emptyList())
        }.sortedByDescending { it.total }
        list
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        val d = parseDate(date)
        DateNavBar(
            label = formatDateShort(d, lang),
            subLabel = weekdayName(d, lang),
            onPrev = { vm.shiftViewDate(-1) },
            onNext = { vm.shiftViewDate(1) },
            onLabelClick = {}
        )
        Spacer(Modifier.height(6.dp))
        if (date != todayStr()) {
            Text(
                "الرجوع لليوم", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = c.primaryDark,
                modifier = Modifier.clickable { vm.setViewDate(todayStr()) }.padding(4.dp)
            )
        }
        Text(
            "إجمالي اليوم: ${vm.money(expenseTotal)}" + if (incomeTotal > 0) " · الدخل: ${vm.money(incomeTotal)} · الصافي: ${vm.money(incomeTotal - expenseTotal)}" else "",
            fontSize = 14.sp, fontWeight = FontWeight.Bold, color = c.primaryDark,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(groups) { group -> ViewAccordionItem(vm, group) }
        }
    }
}

@Composable
fun ViewAccordionItem(vm: AppViewModel, group: ViewCategoryGroup) {
    val c = LocalAppColors.current
    var expanded by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.card).animateContentSize()
    ) {
        Row(
            Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(AppIcons.forCategory(group.category.iconKey), contentDescription = null, tint = c.primaryDark, modifier = Modifier.height(20.dp))
            Spacer(Modifier.padding(horizontal = 4.dp))
            Text(
                group.category.customName ?: stringResource(group.category.nameRes),
                fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = c.text, modifier = Modifier.weight(1f)
            )
            Text(if (group.total > 0) vm.money(group.total) else "-", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = c.primaryDark)
        }
        if (expanded) {
            Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
                if (group.category.isIncome) {
                    if (group.income.isEmpty()) Text("لا يوجد صرف في هذا القسم", fontSize = 12.sp, color = c.textSoft)
                    group.income.forEach { e -> ViewEntryDetail(vm, e.type, e.amount, e.note, JsonUtil.stringsFromJson(e.tagsJson), null) }
                } else {
                    if (group.expenses.isEmpty()) Text("لا يوجد صرف في هذا القسم", fontSize = 12.sp, color = c.textSoft)
                    group.expenses.forEach { e ->
                        ViewEntryDetail(vm, e.type, e.amount, e.note, JsonUtil.stringsFromJson(e.tagsJson), e.splitCount, JsonUtil.itemsFromJson(e.itemsJson))
                    }
                }
            }
        }
    }
}

@Composable
fun ViewEntryDetail(
    vm: AppViewModel, type: String, amount: Double, note: String, tags: List<String>,
    splitCount: Int?, items: List<com.example.expensetracker.data.ItemLine> = emptyList()
) {
    val c = LocalAppColors.current
    Column(
        Modifier.fillMaxWidth().padding(top = 8.dp)
            .background(c.bg, RoundedCornerShape(10.dp)).padding(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(type.ifBlank { "بدون عنوان" }, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = c.text)
            Text(vm.money(amount), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = c.primaryDark)
        }
        items.forEach { Text("${it.name} — ${vm.money(it.price)}", fontSize = 12.sp, color = c.textSoft, modifier = Modifier.padding(top = 2.dp)) }
        if (note.isNotBlank()) Text(note, fontSize = 11.5.sp, color = c.textSoft, modifier = Modifier.padding(top = 4.dp))
        if (tags.isNotEmpty()) {
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { tags.forEach { TagChip(it) } }
        }
        if (splitCount != null && splitCount > 1) {
            Text("مقسومة على $splitCount — نصيبك: ${vm.money(amount / splitCount)}", fontSize = 11.sp, color = c.primaryDark, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
