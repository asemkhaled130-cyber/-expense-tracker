package com.example.expensetracker.util

import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val ISO: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE

fun todayStr(): String = LocalDate.now().format(ISO)

fun shiftDate(dateStr: String, deltaDays: Long): String =
    LocalDate.parse(dateStr, ISO).plusDays(deltaDays).format(ISO)

fun parseDate(dateStr: String): LocalDate = LocalDate.parse(dateStr, ISO)

private val WEEKDAYS_AR = arrayOf("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")
private val MONTHS_AR = arrayOf(
    "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
    "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
)
private val WEEKDAYS_EN = arrayOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
private val MONTHS_EN = arrayOf(
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
)

/** DayOfWeek.value: الاثنين=1 .. الأحد=7 */
fun weekdayName(date: LocalDate, lang: String): String =
    if (lang == "en") WEEKDAYS_EN[date.dayOfWeek.value - 1] else WEEKDAYS_AR[date.dayOfWeek.value - 1]

fun monthName(monthIndex1to12: Int, lang: String): String =
    if (lang == "en") MONTHS_EN[monthIndex1to12 - 1] else MONTHS_AR[monthIndex1to12 - 1]

fun formatDateFull(date: LocalDate, lang: String): String =
    "${weekdayName(date, lang)} ${date.dayOfMonth} ${monthName(date.monthValue, lang)} ${date.year}"

fun formatDateShort(date: LocalDate, lang: String): String =
    "${date.dayOfMonth} ${monthName(date.monthValue, lang)} ${date.year}"
