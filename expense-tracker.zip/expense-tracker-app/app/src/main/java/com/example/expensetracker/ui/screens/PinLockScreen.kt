package com.example.expensetracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetracker.ui.theme.LocalAppColors

@Composable
fun PinLockScreen(
    verify: (String) -> Boolean,
    onUnlocked: () -> Unit,
    onRequestBiometric: (() -> Unit)? = null
) {
    val c = LocalAppColors.current
    var buffer by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    LaunchedEffect(onRequestBiometric) { onRequestBiometric?.invoke() }

    LaunchedEffect(buffer) {
        if (buffer.length in 4..6 && verify(buffer)) {
            onUnlocked()
        } else if (buffer.length >= 6) {
            error = true
            buffer = ""
        }
    }

    Column(
        Modifier.fillMaxSize().background(c.bg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Outlined.Lock, contentDescription = null, tint = c.primary, modifier = Modifier.size(46.dp))
        Spacer(Modifier.height(14.dp))
        Text("أدخل رقم القفل", fontSize = 17.sp, color = c.text)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(4) { i ->
                Box(
                    Modifier.size(14.dp).border(2.dp, c.primary, CircleShape)
                        .background(if (i < buffer.length) c.primary else androidx.compose.ui.graphics.Color.Transparent, CircleShape)
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(if (error) "رقم غير صحيح، حاول تاني" else " ", color = c.danger, fontSize = 12.5.sp)
        Spacer(Modifier.height(16.dp))

        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫")
        LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(280.dp)) {
            items(keys) { k ->
                Box(
                    Modifier.padding(10.dp).size(64.dp).clickable(enabled = k.isNotEmpty()) {
                        error = false
                        when (k) {
                            "⌫" -> buffer = buffer.dropLast(1)
                            "" -> {}
                            else -> if (buffer.length < 6) buffer += k
                        }
                    }.background(if (k.isNotEmpty()) c.card else androidx.compose.ui.graphics.Color.Transparent, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(k, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = c.text)
                }
            }
        }
    }
}
