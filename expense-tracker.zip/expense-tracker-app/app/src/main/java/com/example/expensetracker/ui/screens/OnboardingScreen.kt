package com.example.expensetracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetracker.ui.theme.Primary
import com.example.expensetracker.ui.theme.PrimaryDark

data class OnboardSlide(val icon: ImageVector, val title: String, val desc: String)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val slides = listOf(
        OnboardSlide(Icons.Outlined.AccountBalanceWallet, "أهلاً بيك في مصروفاتي", "سجّل مصروفاتك اليومية بسهولة، وأضف تصنيفات خاصة بيك."),
        OnboardSlide(Icons.Outlined.CalendarMonth, "راجع أي يوم فات", "من شاشة عرض ارجع لأي يوم قبل كده، وسجّل دخلك كمان."),
        OnboardSlide(Icons.Outlined.BarChart, "تابع ميزانيتك", "حدد ميزانية شهرية هتنبهك قبل ما تعديها، وشوف تقارير أسبوعية وشهرية وسنوية."),
        OnboardSlide(Icons.Outlined.Shield, "بياناتك في أمان", "بياناتك على جهازك، مع نسخة احتياطية اختيارية على Google Drive وقفل برقم سري."),
    )
    var index by remember { mutableIntStateOf(0) }

    Column(
        Modifier.fillMaxSize()
            .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Primary, PrimaryDark)))
            .padding(30.dp, 40.dp)
    ) {
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            androidx.compose.material3.Icon(slides[index].icon, contentDescription = null, tint = Color.White, modifier = Modifier.height(64.dp).width(64.dp))
            Spacer(Modifier.height(20.dp))
            Text(slides[index].title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text(slides[index].desc, fontSize = 14.sp, color = Color.White.copy(alpha = 0.9f), textAlign = TextAlign.Center, lineHeight = 22.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            slides.indices.forEach { i ->
                Spacer(
                    Modifier
                        .padding(horizontal = 3.dp)
                        .height(7.dp)
                        .width(if (i == index) 20.dp else 7.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (i == index) Color.White else Color.White.copy(alpha = 0.4f))
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onFinish) { Text("تخطي", color = Color.White.copy(alpha = 0.85f)) }
            Button(
                onClick = { if (index >= slides.size - 1) onFinish() else index++ },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = PrimaryDark)
            ) { Text(if (index >= slides.size - 1) "ابدأ" else "التالي", fontWeight = FontWeight.Bold) }
        }
    }
}
