package com.example.expensetracker.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF0D9488)
val PrimaryDark = Color(0xFF0F766E)
val PrimaryLightLight = Color(0xFFCCFBF1)
val PrimaryLightDark = Color(0xFF0F3733)
val Danger = Color(0xFFDC2626)
val Warning = Color(0xFFD97706)
val WarningLightLight = Color(0xFFFEF3C7)
val WarningLightDark = Color(0xFF3F2F0C)

val BgLight = Color(0xFFF4F6F7)
val BgDark = Color(0xFF111827)
val CardLight = Color(0xFFFFFFFF)
val CardDark = Color(0xFF1F2937)
val TextLight = Color(0xFF1F2937)
val TextDark = Color(0xFFF3F4F6)
val TextSoftLight = Color(0xFF6B7280)
val TextSoftDark = Color(0xFF9CA3AF)
val BorderLight = Color(0xFFE5E7EB)
val BorderDark = Color(0xFF374151)

val ReportColors = listOf(
    Color(0xFF0F766E), Color(0xFF0D9488), Color(0xFF0E9F95), Color(0xFF14B8A6),
    Color(0xFF2DD4BF), Color(0xFF4DD8C9), Color(0xFF6EE0D3), Color(0xFF8FE8DC), Color(0xFFB3F0E6)
)
