package com.example.expensetracker.util

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * يقرأ النص من صورة فاتورة عبر ML Kit (يعمل بالكامل على الجهاز، بدون اتصال إنترنت أو سحابة)
 * ثم يحاول تخمين "المبلغ الإجمالي" من الأرقام الموجودة (أكبر رقم عشري معقول في النص عادة يكون الإجمالي).
 */
object OcrHelper {

    suspend fun recognizeText(context: Context, uri: Uri): String = suspendCancellableCoroutine { cont ->
        try {
            val image = InputImage.fromFilePath(context, uri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { result -> cont.resume(result.text) }
                .addOnFailureListener { e -> cont.resumeWithException(e) }
        } catch (e: Exception) {
            cont.resumeWithException(e)
        }
    }

    /** يحاول استخراج أكبر رقم عشري معقول من النص (غالبًا هو إجمالي الفاتورة) */
    fun guessAmount(text: String): Double? {
        val regex = Regex("""\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{1,2})?""")
        val candidates = regex.findAll(text)
            .map { it.value.replace(",", "").replace(Regex("""\.(?=\d{3}(?:\D|$))"""), "") }
            .mapNotNull { it.toDoubleOrNull() }
            .filter { it in 1.0..100000.0 }
            .toList()
        return candidates.maxOrNull()
    }
}
