package com.example.expensetracker.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetracker.data.CurrencyEntity
import com.example.expensetracker.data.WalletEntity
import com.example.expensetracker.model.Categories
import com.example.expensetracker.model.Category
import com.example.expensetracker.ui.components.SectionLabel
import com.example.expensetracker.ui.icons.AppIcons
import com.example.expensetracker.ui.theme.LocalAppColors
import com.example.expensetracker.viewmodel.AppViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: AppViewModel, onOpenPrivacy: () -> Unit, onRateApp: () -> Unit, onConnectDrive: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { GeneralSection(vm) }
        item { BudgetSection(vm) }
        item { CategoriesSection(vm) }
        item { RecurringSection(vm) }
        item { SecuritySection(vm) }
        item { NotificationsAndCloudSection(vm, onConnectDrive) }
        item { DataSection(vm) }
        item { AboutSection(onOpenPrivacy, onRateApp) }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
fun SettingsSection(icon: ImageVector, title: String, initiallyOpen: Boolean = false, content: @Composable () -> Unit) {
    val c = LocalAppColors.current
    var open by remember { mutableStateOf(initiallyOpen) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.card).animateContentSize()
    ) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = c.primaryDark, modifier = Modifier.height(19.dp))
            Spacer(Modifier.width(10.dp))
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = c.text, modifier = Modifier.weight(1f))
            Text(if (open) "▴" else "▾", color = c.textSoft)
        }
        if (open) {
            Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                content()
            }
        }
    }
}

@Composable
fun SettingsRow(label: String, content: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
fun GeneralSection(vm: AppViewModel) {
    val c = LocalAppColors.current
    val theme by vm.theme.collectAsState()
    val language by vm.language.collectAsState()
    val currency by vm.baseCurrency.collectAsState()
    val wallets by vm.wallets.collectAsState()
    val currencies by vm.currencies.collectAsState()

    SettingsSection(AppIcons.Theme, "عام", initiallyOpen = true) {
        SettingsRow("الوضع الليلي") {
            SimpleDropdown(
                selected = when (theme) { "light" -> "فاتح"; "dark" -> "غامق"; else -> "تلقائي" },
                options = listOf("تلقائي" to "auto", "فاتح" to "light", "غامق" to "dark"),
                onSelect = { vm.setTheme(it) }
            )
        }
        SettingsRow("لغة التطبيق") {
            SimpleDropdown(
                selected = if (language == "en") "English" else "العربية",
                options = listOf("العربية" to "ar", "English" to "en"),
                onSelect = { vm.setLanguage(it) }
            )
        }
        SettingsRow("العملة الأساسية") {
            SimpleDropdown(
                selected = currency,
                options = listOf("جنيه" to "جنيه", "$" to "$", "ر.س" to "ر.س", "د.إ" to "د.إ", "د.ك" to "د.ك", "ر.ق" to "ر.ق", "د.أ" to "د.أ"),
                onSelect = { vm.setCurrency(it) }
            )
        }

        SectionLabel("المحافظ")
        wallets.forEach { w ->
            MiniListItem(w.name, if (w.id != "main") { { vm.deleteWallet(w.id) } } else null)
        }
        AddRow(placeholder = "اسم محفظة جديدة") { name -> vm.addWallet(name) }

        SectionLabel("عملات إضافية (لتحويل يدوي عند التسجيل)")
        currencies.forEach { curr ->
            MiniListItem("${curr.code} — 1 ${curr.code} = ${curr.rate} $currency") { vm.deleteCurrency(curr.code) }
        }
        AddCurrencyRow { code, rate -> vm.addCurrency(code, rate) }
    }
}

@Composable
fun SimpleDropdown(selected: String, options: List<Pair<String, String>>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box2 {
        Text(
            selected, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            color = LocalAppColors.current.primaryDark,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(LocalAppColors.current.primaryLight)
                .clickable { expanded = true }
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (label, value) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { onSelect(value); expanded = false })
            }
        }
    }
}

@Composable
fun Box2(content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.Box { content() }
}

@Composable
fun MiniListItem(text: String, onDelete: (() -> Unit)?) {
    val c = LocalAppColors.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(c.bg).padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, fontSize = 12.5.sp, color = c.text, modifier = Modifier.weight(1f))
        if (onDelete != null) {
            Icon(AppIcons.Close, contentDescription = null, tint = c.danger, modifier = Modifier.height(16.dp).clickable { onDelete() })
        }
    }
}

@Composable
fun AddRow(placeholder: String, onAdd: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = value, onValueChange = { value = it }, modifier = Modifier.weight(1f), placeholder = { Text(placeholder) }, singleLine = true)
        IconButton(onClick = { if (value.isNotBlank()) { onAdd(value.trim()); value = "" } }) { Icon(AppIcons.Add, contentDescription = null) }
    }
}

@Composable
fun AddCurrencyRow(onAdd: (String, Double) -> Unit) {
    var code by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(value = code, onValueChange = { code = it }, modifier = Modifier.weight(1f), placeholder = { Text("رمز العملة USD") }, singleLine = true)
        OutlinedTextField(value = rate, onValueChange = { rate = it }, modifier = Modifier.weight(1f), placeholder = { Text("سعرها") }, singleLine = true)
        IconButton(onClick = {
            val r = rate.toDoubleOrNull()
            if (code.isNotBlank() && r != null && r > 0) { onAdd(code.trim().uppercase(), r); code = ""; rate = "" }
        }) { Icon(AppIcons.Add, contentDescription = null) }
    }
}

@Composable
fun BudgetSection(vm: AppViewModel) {
    val budgets by vm.budgets.collectAsState()
    val categories by vm.categories.collectAsState()
    val savingsGoal by vm.savingsGoal.collectAsState()

    var overallText by remember(budgets) { mutableStateOf(budgets.find { it.categoryId == "__overall__" }?.amount?.let { numToStr2(it) } ?: "") }
    var goalText by remember(savingsGoal) { mutableStateOf(savingsGoal?.let { numToStr2(it) } ?: "") }
    val catBudgetTexts = remember(budgets, categories) {
        androidx.compose.runtime.mutableStateMapOf<String, String>().apply {
            categories.forEach { cat -> this[cat.id] = budgets.find { it.categoryId == cat.id }?.amount?.let { numToStr2(it) } ?: "" }
        }
    }

    SettingsSection(AppIcons.Target, "الميزانية والادخار") {
        SettingsRow("ميزانية شهرية عامة") {
            OutlinedTextField(value = overallText, onValueChange = { overallText = it }, modifier = Modifier.width(120.dp), singleLine = true, placeholder = { Text("اختياري") })
        }
        SectionLabel("ميزانية لكل قسم (اختياري)")
        categories.forEach { cat ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(cat.customName ?: stringResource(cat.nameRes), fontSize = 12.5.sp)
                OutlinedTextField(
                    value = catBudgetTexts[cat.id] ?: "", onValueChange = { catBudgetTexts[cat.id] = it },
                    modifier = Modifier.width(100.dp), singleLine = true, placeholder = { Text("—") }
                )
            }
        }
        SettingsRow("هدف الادخار الشهري") {
            OutlinedTextField(value = goalText, onValueChange = { goalText = it }, modifier = Modifier.width(120.dp), singleLine = true, placeholder = { Text("اختياري") })
        }
        Button(
            onClick = {
                vm.saveOverallBudget(overallText.toDoubleOrNull())
                categories.forEach { cat -> vm.saveCategoryBudget(cat.id, catBudgetTexts[cat.id]?.toDoubleOrNull()) }
                vm.setSavingsGoal(goalText.toDoubleOrNull())
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("حفظ الميزانية والهدف") }
    }
}

@Composable
fun CategoriesSection(vm: AppViewModel) {
    val customCats by vm.categories.collectAsState()
    var newName by remember { mutableStateOf("") }
    var selectedIcon by remember { mutableStateOf("misc") }

    SettingsSection(AppIcons.Category, "التصنيفات") {
        SectionLabel("التصنيفات الأساسية (ثابتة)")
        Row(Modifier.fillMaxWidth()) {
            Text(
                Categories.BUILTIN.joinToString("  ·  ") { stringResource(it.nameRes) },
                fontSize = 11.5.sp, color = LocalAppColors.current.textSoft
            )
        }
        SectionLabel("تصنيفاتك الخاصة")
        val custom = customCats.filter { it.isCustom }
        if (custom.isEmpty()) Text("لا يوجد تصنيفات خاصة بعد", fontSize = 12.sp, color = LocalAppColors.current.textSoft)
        custom.forEach { cat -> MiniListItem(cat.customName ?: "", { vm.deleteCategory(cat.id) }) }

        OutlinedTextField(value = newName, onValueChange = { newName = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("اسم التصنيف الجديد") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Categories.ICON_CHOICES.forEach { key ->
                val sel = key == selectedIcon
                androidx.compose.foundation.layout.Box(
                    Modifier.clip(RoundedCornerShape(20.dp))
                        .background(if (sel) LocalAppColors.current.primary else LocalAppColors.current.bg)
                        .clickable { selectedIcon = key }.padding(8.dp)
                ) {
                    Icon(AppIcons.forCategory(key), contentDescription = null, tint = if (sel) androidx.compose.ui.graphics.Color.White else LocalAppColors.current.textSoft, modifier = Modifier.height(16.dp))
                }
            }
        }
        Button(onClick = { if (newName.isNotBlank()) { vm.addCategory(newName.trim(), selectedIcon); newName = "" } }, modifier = Modifier.fillMaxWidth()) {
            Icon(AppIcons.Add, contentDescription = null); Text("  إضافة تصنيف")
        }
    }
}

@Composable
fun RecurringSection(vm: AppViewModel) {
    val recurring by vm.recurring.collectAsState()
    val categories by vm.categories.collectAsState()
    var catId by remember(categories) { mutableStateOf(categories.firstOrNull()?.id ?: "") }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var day by remember { mutableStateOf("") }

    SettingsSection(AppIcons.Repeat, "مصاريف متكررة") {
        if (recurring.isEmpty()) Text("لا يوجد مصاريف متكررة", fontSize = 12.sp, color = LocalAppColors.current.textSoft)
        recurring.forEach { r ->
            val cat = categories.find { it.id == r.categoryId }
            MiniListItem("${r.title} — يوم ${r.day} — ${vm.money(r.amount)}") { vm.deleteRecurring(r.id) }
        }
        SimpleDropdown(
            selected = categories.find { it.id == catId }?.let { it.customName ?: "قسم" } ?: "اختر قسم",
            options = categories.map { (it.customName ?: it.id) to it.id },
            onSelect = { catId = it }
        )
        OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("العنوان: اشتراك إنترنت") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = amount, onValueChange = { amount = it }, modifier = Modifier.weight(1f), placeholder = { Text("المبلغ") }, singleLine = true)
            OutlinedTextField(value = day, onValueChange = { day = it }, modifier = Modifier.weight(1f), placeholder = { Text("يوم الشهر 1-28") }, singleLine = true)
        }
        Button(
            onClick = {
                val a = amount.toDoubleOrNull(); val d = day.toIntOrNull()
                if (title.isNotBlank() && a != null && a > 0 && d != null && d in 1..28 && catId.isNotBlank()) {
                    vm.addRecurring(catId, title.trim(), a, d)
                    title = ""; amount = ""; day = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Icon(AppIcons.Add, contentDescription = null); Text("  إضافة مصروف متكرر") }
        Text("هتُضاف تلقائيًا كل شهر لما تفتح التطبيق بعد وصول اليوم المحدد.", fontSize = 11.sp, color = LocalAppColors.current.textSoft)
    }
}

private fun numToStr2(n: Double): String = if (n == n.toLong().toDouble()) n.toLong().toString() else n.toString()

@Composable
fun SecuritySection(vm: AppViewModel) {
    val c = LocalAppColors.current
    val pinEnabled by vm.pinEnabled.collectAsState()
    val biometricEnabled by vm.biometricEnabled.collectAsState()
    val autoLock by vm.autoLockMinutes.collectAsState()
    var showPinSetup by remember { mutableStateOf(false) }
    var pin1 by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }

    SettingsSection(AppIcons.Lock, "الأمان") {
        SettingsRow("قفل برقم سري (PIN)") {
            Switch(checked = pinEnabled, onCheckedChange = { checked ->
                if (checked) { showPinSetup = true }
                else { vm.setPin(false, null); vm.setBiometricEnabled(false) }
            })
        }
        if (showPinSetup) {
            OutlinedTextField(value = pin1, onValueChange = { pin1 = it }, label = { Text("رقم سري جديد (4-6 أرقام)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = pin2, onValueChange = { pin2 = it }, label = { Text("تأكيد الرقم السري") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            if (pinError.isNotEmpty()) Text(pinError, color = c.danger, fontSize = 11.5.sp)
            Button(onClick = {
                if (pin1.length !in 4..6) { pinError = "الرقم السري لازم يكون بين 4 و6 أرقام"; return@Button }
                if (pin1 != pin2) { pinError = "الرقمان غير متطابقين"; return@Button }
                vm.setPin(true, pin1)
                showPinSetup = false; pin1 = ""; pin2 = ""; pinError = ""
            }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الرقم السري") }
        } else if (pinEnabled) {
            OutlinedButton(onClick = { showPinSetup = true }, modifier = Modifier.fillMaxWidth()) { Text("تغيير الرقم السري") }
            SettingsRow("استخدام بصمة الإصبع بدل PIN") {
                Switch(checked = biometricEnabled, onCheckedChange = { vm.setBiometricEnabled(it) })
            }
        }
        SettingsRow("قفل تلقائي بعد") {
            SimpleDropdown(
                selected = when (autoLock) { 0 -> "فورًا"; 1 -> "دقيقة"; 30 -> "30 دقيقة"; else -> "5 دقائق" },
                options = listOf("فورًا" to "0", "دقيقة" to "1", "5 دقائق" to "5", "30 دقيقة" to "30"),
                onSelect = { vm.setAutoLockMinutes(it.toInt()) }
            )
        }
        Text("القفل حماية بسيطة لمنع فتح التطبيق مباشرة، مش تشفير كامل للبيانات.", fontSize = 11.sp, color = c.textSoft)
    }
}

@Composable
fun NotificationsAndCloudSection(vm: AppViewModel, onConnectDrive: () -> Unit) {
    val c = LocalAppColors.current
    val context = androidx.compose.ui.platform.LocalContext.current
    val reminderEnabled by vm.reminderEnabled.collectAsState()
    val reminderHour by vm.reminderHour.collectAsState()
    val reminderMinute by vm.reminderMinute.collectAsState()
    val driveEmail by vm.driveAccountEmail.collectAsState()
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    SettingsSection(AppIcons.Notifications, "التذكيرات والنسخ السحابي") {
        SettingsRow("تذكير يومي لو نسيت تسجّل") {
            Switch(checked = reminderEnabled, onCheckedChange = { checked ->
                vm.setReminder(checked, reminderHour, reminderMinute)
                if (checked) com.example.expensetracker.util.NotificationHelper.scheduleDaily(context, reminderHour, reminderMinute)
                else com.example.expensetracker.util.NotificationHelper.cancel(context)
            })
        }
        if (reminderEnabled) {
            SettingsRow("وقت التذكير") {
                SimpleDropdown(
                    selected = "%02d:%02d".format(reminderHour, reminderMinute),
                    options = listOf(18, 19, 20, 21, 22).map { h -> "%02d:00".format(h) to h.toString() },
                    onSelect = { h ->
                        vm.setReminder(true, h.toInt(), 0)
                        com.example.expensetracker.util.NotificationHelper.scheduleDaily(context, h.toInt(), 0)
                    }
                )
            }
        }
        SectionLabel("نسخ احتياطي على Google Drive")
        Text("احفظ نسخة من بياناتك في Google Drive الخاص بيك، وارجعلها من أي جهاز. (يتطلب إعداد مشروع Google Cloud من المطوّر — راجع README)", fontSize = 11.sp, color = c.textSoft)
        var driveMsg by remember { mutableStateOf("") }
        if (driveEmail == null) {
            OutlinedButton(onClick = onConnectDrive, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الدخول بحساب Google") }
        } else {
            Text("متصل بحساب: $driveEmail", fontSize = 12.sp, color = c.primaryDark, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    val account = com.example.expensetracker.util.DriveBackupHelper.lastSignedInAccount(context) ?: return@OutlinedButton
                    scope.launch {
                        val json = vm.repo.exportBackupJson()
                        val ok = com.example.expensetracker.util.DriveBackupHelper.backup(context, account, json)
                        driveMsg = if (ok) "تم النسخ الاحتياطي بنجاح" else "فشل النسخ الاحتياطي"
                    }
                }) { Text("نسخ احتياطي الآن") }
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    val account = com.example.expensetracker.util.DriveBackupHelper.lastSignedInAccount(context) ?: return@OutlinedButton
                    scope.launch {
                        val json = com.example.expensetracker.util.DriveBackupHelper.restore(context, account)
                        if (json != null) {
                            val ok = vm.repo.importBackupJson(json)
                            driveMsg = if (ok) "تم الاستعادة بنجاح" else "فشلت الاستعادة"
                            if (ok) { vm.loadRegisterDay(); vm.loadViewDay() }
                        } else driveMsg = "لا يوجد نسخة محفوظة على Drive"
                    }
                }) { Text("استعادة") }
            }
            if (driveMsg.isNotEmpty()) Text(driveMsg, fontSize = 12.sp, color = c.primaryDark)
        }
    }
}

@Composable
fun DataSection(vm: AppViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var showResetConfirm by remember { mutableStateOf(false) }
    var restoreMsg by remember { mutableStateOf("") }
    val restoreLauncher = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (text != null) {
                    val ok = vm.repo.importBackupJson(text)
                    restoreMsg = if (ok) "تم الاستعادة بنجاح" else "ملف غير صالح"
                    if (ok) { vm.loadRegisterDay(); vm.loadViewDay() }
                }
            }
        }
    }

    SettingsSection(AppIcons.Backup, "البيانات") {
        Button(onClick = {
            scope.launch {
                val rows = vm.repo.exportAllRows()
                val file = com.example.expensetracker.util.Exporters.exportCsv(context, rows, "كل_المصروفات.csv")
                com.example.expensetracker.util.Exporters.shareFile(context, file, "text/csv")
            }
        }, modifier = Modifier.fillMaxWidth()) { Icon(AppIcons.Chart, contentDescription = null); Text("  تصدير كل البيانات (CSV)") }

        OutlinedButton(onClick = {
            scope.launch {
                val rows = vm.repo.exportAllRows()
                val file = com.example.expensetracker.util.Exporters.exportPdf(context, "كل المصروفات", rows, "كل_المصروفات.pdf")
                com.example.expensetracker.util.Exporters.shareFile(context, file, "application/pdf")
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("طباعة / PDF لكل البيانات") }

        OutlinedButton(onClick = {
            scope.launch {
                val json = vm.repo.exportBackupJson()
                val file = com.example.expensetracker.util.Exporters.exportJson(context, json, "نسخة_احتياطية.json")
                com.example.expensetracker.util.Exporters.shareFile(context, file, "application/json")
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("نسخة احتياطية محلية (JSON)") }

        OutlinedButton(onClick = { restoreLauncher.launch("application/json") }, modifier = Modifier.fillMaxWidth()) { Text("استعادة نسخة احتياطية") }
        if (restoreMsg.isNotEmpty()) Text(restoreMsg, fontSize = 12.sp, color = LocalAppColors.current.primaryDark)

        if (showResetConfirm) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showResetConfirm = false },
                title = { Text("حذف كل البيانات") },
                text = { Text("هل أنت متأكد؟ لا يمكن التراجع.") },
                confirmButton = {
                    androidx.compose.material3.TextButton(onClick = {
                        scope.launch { vm.repo.expenseDao.deleteAll(); vm.repo.incomeDao.deleteAll(); vm.loadRegisterDay(); vm.loadViewDay() }
                        showResetConfirm = false
                    }) { Text("حذف") }
                },
                dismissButton = { androidx.compose.material3.TextButton(onClick = { showResetConfirm = false }) { Text("إلغاء") } }
            )
        }
        OutlinedButton(
            onClick = { showResetConfirm = true }, modifier = Modifier.fillMaxWidth(),
            colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = LocalAppColors.current.danger)
        ) { Text("حذف كل البيانات") }
    }
}

@Composable
fun AboutSection(onOpenPrivacy: () -> Unit, onRateApp: () -> Unit) {
    val c = LocalAppColors.current
    SettingsSection(AppIcons.Shield, "عن التطبيق") {
        OutlinedButton(onClick = onOpenPrivacy, modifier = Modifier.fillMaxWidth()) { Text("سياسة الخصوصية") }
        OutlinedButton(onClick = onRateApp, modifier = Modifier.fillMaxWidth()) { Text("قيّم التطبيق") }
        Text(androidx.compose.ui.res.stringResource(com.example.expensetracker.R.string.about_version), fontSize = 11.sp, color = c.textSoft)
        androidx.compose.foundation.layout.Column(
            Modifier.fillMaxWidth().padding(top = 6.dp),
            horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
        ) {
            androidx.compose.material3.HorizontalDivider(color = c.border, modifier = Modifier.padding(bottom = 10.dp))
            Text(
                androidx.compose.ui.res.stringResource(com.example.expensetracker.R.string.developed_by),
                fontSize = 12.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.primaryDark,
                letterSpacing = 0.3.sp
            )
        }
    }
}
