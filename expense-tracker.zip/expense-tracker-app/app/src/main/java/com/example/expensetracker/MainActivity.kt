package com.example.expensetracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.expensetracker.ui.icons.AppIcons
import com.example.expensetracker.ui.screens.OnboardingScreen
import com.example.expensetracker.ui.screens.PinLockScreen
import com.example.expensetracker.ui.screens.RegisterScreen
import com.example.expensetracker.ui.screens.ReportsScreen
import com.example.expensetracker.ui.screens.SearchScreen
import com.example.expensetracker.ui.screens.SettingsScreen
import com.example.expensetracker.ui.screens.ViewScreen
import com.example.expensetracker.ui.theme.ExpenseTrackerTheme
import com.example.expensetracker.util.BiometricHelper
import com.example.expensetracker.util.DriveBackupHelper
import com.example.expensetracker.viewmodel.AppViewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val vm: AppViewModel by viewModels()

    private val notifPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private val driveSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            vm.setDriveAccountEmail(account.email)
        } catch (e: ApiException) { /* المستخدم ألغى تسجيل الدخول أو حصل خطأ */ }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            val theme by vm.theme.collectAsState()
            val language by vm.language.collectAsState()
            val darkTheme = when (theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }

            androidx.compose.runtime.LaunchedEffect(language) {
                val locales = LocaleListCompat.forLanguageTags(language)
                if (AppCompatDelegate.getApplicationLocales() != locales) AppCompatDelegate.setApplicationLocales(locales)
            }

            ExpenseTrackerTheme(darkTheme = darkTheme) {
                AppRoot(
                    vm = vm,
                    onRequestBiometric = { onSuccess, onError -> BiometricHelper.authenticate(this, "تحقق للدخول", onSuccess, onError) },
                    onConnectDrive = { driveSignInLauncher.launch(DriveBackupHelper.getSignInIntent(this)) },
                    activity = this
                )
            }
        }
    }
}

@Composable
fun AppRoot(
    vm: AppViewModel,
    onRequestBiometric: (onSuccess: () -> Unit, onError: () -> Unit) -> Unit,
    onConnectDrive: () -> Unit,
    activity: MainActivity
) {
    val onboardingSeen by vm.onboardingSeen.collectAsState()
    val pinEnabled by vm.pinEnabled.collectAsState()
    val biometricEnabled by vm.biometricEnabled.collectAsState()
    val autoLockMinutes by vm.autoLockMinutes.collectAsState()
    val scope = rememberCoroutineScope()

    var locked by remember { mutableStateOf(false) }
    var checkedOnce by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf("register") }
    var searchOpen by remember { mutableStateOf(false) }
    var showPrivacy by remember { mutableStateOf(false) }

    suspend fun checkLock() {
        if (pinEnabled) {
            val last = vm.lastActiveTs()
            val elapsed = System.currentTimeMillis() - last
            if (last == 0L || elapsed > autoLockMinutes * 60000L) locked = true
        }
    }

    // فحص القفل عند أول ظهور، ثم عند كل رجوع للتطبيق من الخلفية
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                scope.launch { checkLock(); checkedOnce = true }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    androidx.compose.runtime.LaunchedEffect(Unit) { checkLock(); checkedOnce = true }

    if (!checkedOnce) return

    when {
        !onboardingSeen -> OnboardingScreen(onFinish = { vm.setOnboardingSeen(true) })
        locked -> PinLockScreen(
            verify = { vm.verifyPin(it) },
            onUnlocked = { locked = false; vm.markActive() },
            onRequestBiometric = if (biometricEnabled) {
                {
                    onRequestBiometric(
                        { locked = false; vm.markActive() },
                        { /* المستخدم هيدخل PIN يدويًا بدلًا من كده */ }
                    )
                }
            } else null
        )
        searchOpen -> SearchScreen(
            vm = vm, onClose = { searchOpen = false },
            onOpenResult = { date, catId ->
                searchOpen = false
                screen = "register"
                vm.setRegisterDate(date)
            }
        )
        showPrivacy -> com.example.expensetracker.ui.screens.PrivacyPolicyScreen(onClose = { showPrivacy = false })
        else -> MainScaffold(
            vm, screen, onScreenChange = { screen = it; vm.markActive() }, onOpenSearch = { searchOpen = true },
            onOpenPrivacy = { showPrivacy = true }, onConnectDrive = onConnectDrive, activity = activity
        )
    }
}

@Composable
fun MainScaffold(
    vm: AppViewModel, screen: String, onScreenChange: (String) -> Unit, onOpenSearch: () -> Unit,
    onOpenPrivacy: () -> Unit, onConnectDrive: () -> Unit, activity: MainActivity
) {
    val language by vm.language.collectAsState()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            androidx.compose.material3.TopAppBar(
                title = { Text(androidx.compose.ui.res.stringResource(R.string.app_name)) },
                actions = {
                    androidx.compose.material3.IconButton(onClick = onOpenSearch) {
                        Icon(AppIcons.Search, contentDescription = null)
                    }
                },
                colors = androidx.compose.material3.TopAppBarDefaults.topAppBarColors(
                    containerColor = com.example.expensetracker.ui.theme.Primary,
                    titleContentColor = androidx.compose.ui.graphics.Color.White,
                    actionIconContentColor = androidx.compose.ui.graphics.Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = screen == "register", onClick = { onScreenChange("register") }, icon = { Icon(Icons.Outlined.Edit, contentDescription = null) }, label = { Text("تسجيل") })
                NavigationBarItem(selected = screen == "view", onClick = { onScreenChange("view") }, icon = { Icon(Icons.Outlined.CalendarMonth, contentDescription = null) }, label = { Text("عرض") })
                NavigationBarItem(selected = screen == "reports", onClick = { onScreenChange("reports") }, icon = { Icon(Icons.Outlined.BarChart, contentDescription = null) }, label = { Text("تقارير") })
                NavigationBarItem(selected = screen == "settings", onClick = { onScreenChange("settings") }, icon = { Icon(Icons.Outlined.Settings, contentDescription = null) }, label = { Text("إعدادات") })
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().background(com.example.expensetracker.ui.theme.LocalAppColors.current.bg).padding(padding)) {
            when (screen) {
                "register" -> RegisterScreen(vm, language)
                "view" -> ViewScreen(vm, language)
                "reports" -> ReportsScreen(vm)
                "settings" -> SettingsScreen(
                    vm,
                    onOpenPrivacy = onOpenPrivacy,
                    onRateApp = { com.example.expensetracker.util.ReviewHelper.requestReview(activity) },
                    onConnectDrive = onConnectDrive
                )
            }
        }
    }
}
