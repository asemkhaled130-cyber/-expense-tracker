package com.example.expensetracker.ui.icons

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Adjust
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.AttachMoney
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Checkroom
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.LocalHospital
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Receipt
import androidx.compose.material.icons.outlined.Repeat
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Sell
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SettingsBackupRestore
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.Theaters
import androidx.compose.material.icons.outlined.Close
import androidx.compose.ui.graphics.vector.ImageVector

object AppIcons {
    val byCategoryKey: Map<String, ImageVector> = mapOf(
        "food" to Icons.Outlined.Restaurant,
        "transport" to Icons.Outlined.DirectionsCar,
        "bills" to Icons.Outlined.Receipt,
        "clothes" to Icons.Outlined.Checkroom,
        "shopping" to Icons.Outlined.ShoppingBag,
        "health" to Icons.Outlined.LocalHospital,
        "fun" to Icons.Outlined.Theaters,
        "rent" to Icons.Outlined.Home,
        "misc" to Icons.Outlined.GridView,
        "income" to Icons.Outlined.AccountBalanceWallet,
    )
    fun forCategory(key: String): ImageVector = byCategoryKey[key] ?: Icons.Outlined.GridView

    val Search = Icons.Outlined.Search
    val Add = Icons.Outlined.Add
    val Edit = Icons.Outlined.Edit
    val Delete = Icons.Outlined.Delete
    val Save = Icons.Outlined.Save
    val Close = Icons.Outlined.Close
    val Camera = Icons.Outlined.CameraAlt
    val Attach = Icons.Outlined.AttachFile
    val Mic = Icons.Outlined.Mic
    val Lock = Icons.Outlined.Lock
    val Fingerprint = Icons.Outlined.Fingerprint
    val Chart = Icons.Outlined.BarChart
    val Backup = Icons.Outlined.Backup
    val Restore = Icons.Outlined.SettingsBackupRestore
    val Print = Icons.Outlined.Print
    val Share = Icons.Outlined.Share
    val Star = Icons.Outlined.Star
    val Shield = Icons.Outlined.Shield
    val Category = Icons.Outlined.Category
    val Theme = Icons.Outlined.DarkMode
    val Repeat = Icons.Outlined.Repeat
    val Tag = Icons.Outlined.Sell
    val Notifications = Icons.Outlined.NotificationsActive
    val Language = Icons.Outlined.Language
    val Wallet = Icons.Outlined.AccountBalanceWallet
    val Calendar = Icons.Outlined.CalendarMonth
    val Settings = Icons.Outlined.Settings
    val ChevronLeft = Icons.Outlined.ChevronLeft
    val ChevronRight = Icons.Outlined.ChevronRight
    val Target = Icons.Outlined.Adjust
    val Money = Icons.Outlined.AttachMoney
    val CloudIcon = Icons.Outlined.Cloud
}
