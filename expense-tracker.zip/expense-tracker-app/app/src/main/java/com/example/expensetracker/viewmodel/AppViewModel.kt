package com.example.expensetracker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.expensetracker.data.AppDatabase
import com.example.expensetracker.data.BudgetEntity
import com.example.expensetracker.data.CategoryEntity
import com.example.expensetracker.data.CurrencyEntity
import com.example.expensetracker.data.ExpenseEntity
import com.example.expensetracker.data.IncomeEntity
import com.example.expensetracker.data.JsonUtil
import com.example.expensetracker.data.RecurringEntity
import com.example.expensetracker.data.Repository
import com.example.expensetracker.data.SettingsRepository
import com.example.expensetracker.data.WalletEntity
import com.example.expensetracker.model.Categories
import com.example.expensetracker.model.Category
import com.example.expensetracker.model.INCOME_CAT_ID
import com.example.expensetracker.util.shiftDate
import com.example.expensetracker.util.todayStr
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

data class BudgetAlert(val isDanger: Boolean, val text: String)
data class CategoryWithTotal(val category: Category, val total: Double, val entryCount: Int)

class AppViewModel(application: Application) : AndroidViewModel(application) {
    val repo = Repository(AppDatabase.getInstance(application), SettingsRepository(application))
    private val fmt = DateTimeFormatter.ISO_LOCAL_DATE

    // ---------- التصنيفات ----------
    val categories = MutableStateFlow<List<Category>>(Categories.BUILTIN)
    val wallets = MutableStateFlow<List<WalletEntity>>(emptyList())
    val currencies = MutableStateFlow<List<CurrencyEntity>>(emptyList())
    val budgets = MutableStateFlow<List<BudgetEntity>>(emptyList())
    val recurring = MutableStateFlow<List<RecurringEntity>>(emptyList())

    // ---------- إعدادات مقروءة كحالة ----------
    val baseCurrency = MutableStateFlow("جنيه")
    val theme = MutableStateFlow("auto")
    val language = MutableStateFlow("ar")
    val onboardingSeen = MutableStateFlow(true)
    val pinEnabled = MutableStateFlow(false)
    val pinHash = MutableStateFlow("")
    val autoLockMinutes = MutableStateFlow(5)
    val biometricEnabled = MutableStateFlow(false)
    val savingsGoal = MutableStateFlow<Double?>(null)
    val reminderEnabled = MutableStateFlow(false)
    val reminderHour = MutableStateFlow(20)
    val reminderMinute = MutableStateFlow(0)
    val driveAccountEmail = MutableStateFlow<String?>(null)

    // ---------- تاريخ اليوم المختار ----------
    val registerDate = MutableStateFlow(todayStr())
    val viewDate = MutableStateFlow(todayStr())
    val registerExpenses = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val registerIncome = MutableStateFlow<List<IncomeEntity>>(emptyList())
    val viewExpenses = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val viewIncome = MutableStateFlow<List<IncomeEntity>>(emptyList())
    val budgetAlerts = MutableStateFlow<List<BudgetAlert>>(emptyList())

    // ---------- تراجع عن الحذف ----------
    private var lastDeletedExpense: ExpenseEntity? = null
    private var lastDeletedIncome: IncomeEntity? = null

    init {
        viewModelScope.launch {
            repo.ensureDefaultWallet()
            repo.applyRecurring()
            reloadStatic()
            observeSettings()
            loadRegisterDay()
            loadViewDay()
        }
    }

    private suspend fun observeSettings() {
        viewModelScope.launch { repo.settings.currency.collect { baseCurrency.value = it } }
        viewModelScope.launch { repo.settings.theme.collect { theme.value = it } }
        viewModelScope.launch { repo.settings.language.collect { language.value = it } }
        viewModelScope.launch { repo.settings.onboardingSeen.collect { onboardingSeen.value = it } }
        viewModelScope.launch { repo.settings.pinEnabled.collect { pinEnabled.value = it } }
        viewModelScope.launch { repo.settings.pinHash.collect { pinHash.value = it } }
        viewModelScope.launch { repo.settings.autoLockMinutes.collect { autoLockMinutes.value = it } }
        viewModelScope.launch { repo.settings.biometricEnabled.collect { biometricEnabled.value = it } }
        viewModelScope.launch { repo.settings.savingsGoal.collect { savingsGoal.value = it } }
        viewModelScope.launch { repo.settings.reminderEnabled.collect { reminderEnabled.value = it } }
        viewModelScope.launch { repo.settings.reminderHour.collect { reminderHour.value = it } }
        viewModelScope.launch { repo.settings.reminderMinute.collect { reminderMinute.value = it } }
        viewModelScope.launch { repo.settings.driveAccountEmail.collect { driveAccountEmail.value = it } }
        viewModelScope.launch { repo.walletsFlow().collect { wallets.value = it } }
        viewModelScope.launch { repo.currenciesFlow().collect { currencies.value = it } }
        viewModelScope.launch { repo.budgetsFlow().collect { budgets.value = it; refreshBudgetAlerts() } }
        viewModelScope.launch { repo.recurringFlow().collect { recurring.value = it } }
        viewModelScope.launch { repo.allCategoriesFlow().collect { categories.value = it } }
    }

    private suspend fun reloadStatic() {
        categories.value = repo.allCategoriesOnce()
        wallets.value = repo.walletDao.getAllOnce()
        currencies.value = repo.currencyDao.getAllOnce()
        budgets.value = repo.budgetDao.getAllOnce()
        recurring.value = repo.recurringDao.getAllOnce()
    }

    fun findCategory(id: String): Category? =
        if (id == INCOME_CAT_ID) Categories.INCOME else categories.value.find { it.id == id }

    // ---------- شاشة التسجيل ----------
    fun loadRegisterDay() {
        viewModelScope.launch {
            repo.expensesForDate(registerDate.value).collect { registerExpenses.value = it }
        }
        viewModelScope.launch {
            repo.incomeForDate(registerDate.value).collect { registerIncome.value = it }
        }
        refreshBudgetAlerts()
    }
    fun setRegisterDate(date: String) { registerDate.value = date; loadRegisterDay() }
    fun shiftRegisterDate(delta: Long) { setRegisterDate(shiftDate(registerDate.value, delta)) }

    fun loadViewDay() {
        viewModelScope.launch { repo.expensesForDate(viewDate.value).collect { viewExpenses.value = it } }
        viewModelScope.launch { repo.incomeForDate(viewDate.value).collect { viewIncome.value = it } }
    }
    fun setViewDate(date: String) { viewDate.value = date; loadViewDay() }
    fun shiftViewDate(delta: Long) { setViewDate(shiftDate(viewDate.value, delta)) }

    fun registerCategoryTotals(): List<CategoryWithTotal> {
        val expByCat = registerExpenses.value.groupBy { it.categoryId }
        return categories.value.map { c ->
            val list = expByCat[c.id] ?: emptyList()
            CategoryWithTotal(c, list.sumOf { it.amount }, list.size)
        }
    }
    fun registerIncomeTotal(): Double = registerIncome.value.sumOf { it.amount }
    fun registerDayTotal(): Double = registerExpenses.value.sumOf { it.amount }

    fun saveExpenseEntry(entity: ExpenseEntity) = viewModelScope.launch {
        repo.saveExpense(entity)
        loadRegisterDay(); loadViewDay()
    }
    fun deleteExpenseEntry(entity: ExpenseEntity) = viewModelScope.launch {
        lastDeletedExpense = entity
        repo.deleteExpense(entity.id)
        loadRegisterDay(); loadViewDay()
    }
    fun undoDeleteExpense() = viewModelScope.launch {
        lastDeletedExpense?.let { repo.saveExpense(it); loadRegisterDay(); loadViewDay() }
        lastDeletedExpense = null
    }
    fun saveIncomeEntry(entity: IncomeEntity) = viewModelScope.launch {
        repo.saveIncome(entity)
        loadRegisterDay(); loadViewDay()
    }
    fun deleteIncomeEntry(entity: IncomeEntity) = viewModelScope.launch {
        lastDeletedIncome = entity
        repo.deleteIncome(entity.id)
        loadRegisterDay(); loadViewDay()
    }
    fun undoDeleteIncome() = viewModelScope.launch {
        lastDeletedIncome?.let { repo.saveIncome(it); loadRegisterDay(); loadViewDay() }
        lastDeletedIncome = null
    }

    /** يتحقق هل المبلغ أعلى من المعتاد بكتير (يرجع متوسط المصروف السابق أو null لو مفيش داعي للتنبيه) */
    suspend fun checkAnomaly(categoryId: String, amount: Double): Double? {
        val past = repo.expenseDao.getByCategory(categoryId).map { it.amount }.filter { it > 0 }
        if (past.size < 3) return null
        val avg = past.average()
        return if (amount > avg * 2.5) avg else null
    }

    // ---------- الميزانية والتنبيهات ----------
    fun refreshBudgetAlerts() = viewModelScope.launch {
        val ym = YearMonth.now()
        val alerts = mutableListOf<BudgetAlert>()
        val overall = budgets.value.find { it.categoryId == "__overall__" }
        if (overall != null && overall.amount > 0) {
            val spent = repo.monthSpend(null, ym)
            val pct = spent / overall.amount
            if (pct >= 1) alerts.add(BudgetAlert(true, "تجاوزت الميزانية الشهرية العامة (${money(spent)} من ${money(overall.amount)})"))
            else if (pct >= 0.8) alerts.add(BudgetAlert(false, "قربت توصل لميزانيتك الشهرية العامة (${(pct * 100).toInt()}%)"))
        }
        budgets.value.filter { it.categoryId != "__overall__" }.forEach { b ->
            val cat = findCategory(b.categoryId) ?: return@forEach
            val spent = repo.monthSpend(b.categoryId, ym)
            val pct = spent / b.amount
            val name = cat.customName ?: cat.id
            if (pct >= 1) alerts.add(BudgetAlert(true, "تجاوزت ميزانية \"$name\" (${money(spent)} من ${money(b.amount)})"))
            else if (pct >= 0.8) alerts.add(BudgetAlert(false, "قربت تعدي ميزانية \"$name\" (${(pct * 100).toInt()}%)"))
        }
        budgetAlerts.value = alerts
    }

    fun money(amount: Double): String {
        val n = if (amount == amount.toLong().toDouble()) amount.toLong().toString()
        else String.format(Locale.US, "%.2f", amount)
        return "$n ${baseCurrency.value}"
    }

    // ---------- التقارير ----------
    data class ReportResult(
        val expenseTotal: Double, val incomeTotal: Double, val net: Double,
        val compareText: String?, val compareUp: Boolean,
        val categoryTotals: List<CategoryWithTotal>, val monthlyTrend: List<Pair<String, Double>>
    )

    suspend fun computeReport(mode: String, anchor: LocalDate): ReportResult {
        val (from, to) = periodRange(mode, anchor)
        val expenses = repo.rangeExpenses(from.format(fmt), to.format(fmt))
        val income = repo.rangeIncome(from.format(fmt), to.format(fmt))
        val expenseTotal = expenses.sumOf { it.amount }
        val incomeTotal = income.sumOf { it.amount }

        val prevAnchor = prevAnchor(mode, anchor)
        val (pf, pt) = periodRange(mode, prevAnchor)
        val prevExpenseTotal = repo.rangeExpenses(pf.format(fmt), pt.format(fmt)).sumOf { it.amount }
        var compareText: String? = null
        var compareUp = false
        if (prevExpenseTotal > 0) {
            val diffPct = (((expenseTotal - prevExpenseTotal) / prevExpenseTotal) * 100).toInt()
            if (diffPct > 2) { compareText = "أعلى بـ $diffPct% عن الفترة السابقة"; compareUp = true }
            else if (diffPct < -2) { compareText = "أقل بـ ${-diffPct}% عن الفترة السابقة"; compareUp = false }
            else compareText = "زي الفترة السابقة تقريبًا"
        }

        val byCat = expenses.groupBy { it.categoryId }
        val catTotals = categories.value.map { c ->
            val list = byCat[c.id] ?: emptyList()
            CategoryWithTotal(c, list.sumOf { it.amount }, list.size)
        }.filter { it.total > 0 }.sortedByDescending { it.total }

        val monthlyTrend = if (mode == "year") {
            (1..12).map { m ->
                val ymo = YearMonth.of(anchor.year, m)
                val total = repo.monthSpend(null, ymo)
                "%02d".format(m) to total
            }
        } else emptyList()

        return ReportResult(expenseTotal, incomeTotal, incomeTotal - expenseTotal, compareText, compareUp, catTotals, monthlyTrend)
    }

    fun periodRange(mode: String, anchor: LocalDate): Pair<LocalDate, LocalDate> = when (mode) {
        "week" -> {
            val diffToSat = (anchor.dayOfWeek.value + 1) % 7
            val start = anchor.minusDays(diffToSat.toLong())
            start to start.plusDays(6)
        }
        "year" -> LocalDate.of(anchor.year, 1, 1) to LocalDate.of(anchor.year, 12, 31)
        else -> anchor.withDayOfMonth(1) to anchor.withDayOfMonth(anchor.lengthOfMonth())
    }
    fun prevAnchor(mode: String, anchor: LocalDate): LocalDate = when (mode) {
        "week" -> anchor.minusWeeks(1)
        "year" -> anchor.minusYears(1)
        else -> anchor.minusMonths(1)
    }
    fun shiftAnchor(mode: String, anchor: LocalDate, delta: Long): LocalDate = when (mode) {
        "week" -> anchor.plusWeeks(delta)
        "year" -> anchor.plusYears(delta)
        else -> anchor.plusMonths(delta)
    }

    // ---------- إعدادات: عام ----------
    fun setTheme(v: String) = viewModelScope.launch { repo.settings.setTheme(v) }
    fun setLanguage(v: String) = viewModelScope.launch { repo.settings.setLanguage(v) }
    fun setCurrency(v: String) = viewModelScope.launch { repo.settings.setCurrency(v) }
    fun setOnboardingSeen(v: Boolean) = viewModelScope.launch { repo.settings.setOnboardingSeen(v) }

    fun addWallet(name: String) = viewModelScope.launch {
        repo.walletDao.upsert(WalletEntity(java.util.UUID.randomUUID().toString(), name))
        reloadStatic()
    }
    fun deleteWallet(id: String) = viewModelScope.launch { repo.walletDao.deleteById(id); reloadStatic() }

    fun addCurrency(code: String, rate: Double) = viewModelScope.launch {
        repo.currencyDao.upsert(CurrencyEntity(code, rate)); reloadStatic()
    }
    fun deleteCurrency(code: String) = viewModelScope.launch { repo.currencyDao.deleteByCode(code); reloadStatic() }

    // ---------- إعدادات: الميزانية ----------
    fun saveOverallBudget(amount: Double?) = viewModelScope.launch {
        if (amount == null || amount <= 0) repo.budgetDao.deleteByCategory("__overall__")
        else repo.budgetDao.upsert(BudgetEntity("__overall__", amount))
        reloadStatic(); refreshBudgetAlerts()
    }
    fun saveCategoryBudget(categoryId: String, amount: Double?) = viewModelScope.launch {
        if (amount == null || amount <= 0) repo.budgetDao.deleteByCategory(categoryId)
        else repo.budgetDao.upsert(BudgetEntity(categoryId, amount))
        reloadStatic(); refreshBudgetAlerts()
    }
    fun setSavingsGoal(v: Double?) = viewModelScope.launch { repo.settings.setSavingsGoal(v) }

    // ---------- إعدادات: التصنيفات ----------
    fun addCategory(name: String, iconKey: String) = viewModelScope.launch {
        repo.categoryDao.upsert(CategoryEntity(java.util.UUID.randomUUID().toString(), name, iconKey, "[]"))
        reloadStatic()
    }
    fun deleteCategory(id: String) = viewModelScope.launch { repo.categoryDao.deleteById(id); reloadStatic() }

    // ---------- إعدادات: متكررة ----------
    fun addRecurring(categoryId: String, title: String, amount: Double, day: Int) = viewModelScope.launch {
        repo.recurringDao.upsert(RecurringEntity(java.util.UUID.randomUUID().toString(), categoryId, title, amount, day, null))
        reloadStatic()
        repo.applyRecurring()
        loadRegisterDay()
    }
    fun deleteRecurring(id: String) = viewModelScope.launch { repo.recurringDao.deleteById(id); reloadStatic() }

    // ---------- إعدادات: الأمان ----------
    fun sha256(text: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(("exp_salt_" + text).toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
    fun setPin(enabled: Boolean, rawPin: String?) = viewModelScope.launch {
        val hash = if (enabled && rawPin != null) sha256(rawPin) else ""
        repo.settings.setPin(enabled, hash)
    }
    fun verifyPin(rawPin: String): Boolean = sha256(rawPin) == pinHash.value
    fun setAutoLockMinutes(v: Int) = viewModelScope.launch { repo.settings.setAutoLockMinutes(v) }
    fun setBiometricEnabled(v: Boolean) = viewModelScope.launch { repo.settings.setBiometricEnabled(v) }
    fun setReminder(enabled: Boolean, hour: Int, minute: Int) = viewModelScope.launch { repo.settings.setReminder(enabled, hour, minute) }
    fun setDriveAccountEmail(email: String?) = viewModelScope.launch { repo.settings.setDriveAccountEmail(email) }
    fun markActive() = viewModelScope.launch { repo.settings.markActive() }
    suspend fun lastActiveTs(): Long = repo.settings.lastActiveTs.first()

    // ---------- البحث ----------
    data class SearchResult(val date: String, val category: Category, val title: String, val amount: Double, val note: String)
    suspend fun search(text: String, from: String?, to: String?, min: Double?, max: Double?, catIds: Set<String>): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        val allExp = repo.expenseDao.getAll()
        val allInc = repo.incomeDao.getAll()
        val lower = text.trim().lowercase()
        allExp.forEach { e ->
            if (catIds.isNotEmpty() && e.categoryId !in catIds) return@forEach
            if (from != null && e.date < from) return@forEach
            if (to != null && e.date > to) return@forEach
            if (min != null && e.amount < min) return@forEach
            if (max != null && e.amount > max) return@forEach
            val items = JsonUtil.itemsFromJson(e.itemsJson).joinToString(" ") { it.name }
            val tags = JsonUtil.stringsFromJson(e.tagsJson).joinToString(" ")
            val hay = "${e.type} ${e.note} $items $tags".lowercase()
            if (lower.isNotEmpty() && !hay.contains(lower)) return@forEach
            val cat = findCategory(e.categoryId) ?: return@forEach
            results.add(SearchResult(e.date, cat, e.type, e.amount, e.note))
        }
        if (catIds.isEmpty() || INCOME_CAT_ID in catIds) {
            allInc.forEach { i ->
                if (from != null && i.date < from) return@forEach
                if (to != null && i.date > to) return@forEach
                if (min != null && i.amount < min) return@forEach
                if (max != null && i.amount > max) return@forEach
                val tags = JsonUtil.stringsFromJson(i.tagsJson).joinToString(" ")
                val hay = "${i.type} ${i.note} $tags".lowercase()
                if (lower.isNotEmpty() && !hay.contains(lower)) return@forEach
                results.add(SearchResult(i.date, Categories.INCOME, i.type, i.amount, i.note))
            }
        }
        return results.sortedByDescending { it.date }
    }
}

