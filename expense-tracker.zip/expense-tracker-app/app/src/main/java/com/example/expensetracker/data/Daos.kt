package com.example.expensetracker.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses WHERE date = :date")
    fun observeByDate(date: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE date BETWEEN :from AND :to")
    suspend fun getByRange(from: String, to: String): List<ExpenseEntity>

    @Query("SELECT * FROM expenses")
    suspend fun getAll(): List<ExpenseEntity>

    @Query("SELECT * FROM expenses")
    fun observeAll(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE categoryId = :categoryId")
    suspend fun getByCategory(categoryId: String): List<ExpenseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ExpenseEntity)

    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM expenses")
    suspend fun deleteAll()
}

@Dao
interface IncomeDao {
    @Query("SELECT * FROM income WHERE date = :date")
    fun observeByDate(date: String): Flow<List<IncomeEntity>>

    @Query("SELECT * FROM income WHERE date BETWEEN :from AND :to")
    suspend fun getByRange(from: String, to: String): List<IncomeEntity>

    @Query("SELECT * FROM income")
    suspend fun getAll(): List<IncomeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: IncomeEntity)

    @Query("DELETE FROM income WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM income")
    suspend fun deleteAll()
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM custom_categories")
    fun observeAll(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM custom_categories")
    suspend fun getAllOnce(): List<CategoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CategoryEntity)

    @Query("DELETE FROM custom_categories WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets")
    fun observeAll(): Flow<List<WalletEntity>>

    @Query("SELECT * FROM wallets")
    suspend fun getAllOnce(): List<WalletEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: WalletEntity)

    @Query("DELETE FROM wallets WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface CurrencyDao {
    @Query("SELECT * FROM currencies")
    fun observeAll(): Flow<List<CurrencyEntity>>

    @Query("SELECT * FROM currencies")
    suspend fun getAllOnce(): List<CurrencyEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CurrencyEntity)

    @Query("DELETE FROM currencies WHERE code = :code")
    suspend fun deleteByCode(code: String)
}

@Dao
interface RecurringDao {
    @Query("SELECT * FROM recurring")
    fun observeAll(): Flow<List<RecurringEntity>>

    @Query("SELECT * FROM recurring")
    suspend fun getAllOnce(): List<RecurringEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: RecurringEntity)

    @Query("DELETE FROM recurring WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budgets")
    fun observeAll(): Flow<List<BudgetEntity>>

    @Query("SELECT * FROM budgets")
    suspend fun getAllOnce(): List<BudgetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: BudgetEntity)

    @Query("DELETE FROM budgets WHERE categoryId = :categoryId")
    suspend fun deleteByCategory(categoryId: String)

    @Query("DELETE FROM budgets")
    suspend fun deleteAll()
}
