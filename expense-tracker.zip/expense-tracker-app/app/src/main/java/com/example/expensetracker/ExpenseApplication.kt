package com.example.expensetracker

import android.app.Application
import com.example.expensetracker.util.NotificationHelper

class ExpenseApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannel(this)
    }
}
