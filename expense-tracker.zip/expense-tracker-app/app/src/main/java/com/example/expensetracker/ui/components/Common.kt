package com.example.expensetracker.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetracker.ui.theme.LocalAppColors
import com.example.expensetracker.ui.theme.ReportColors
import kotlin.math.min

@Composable
fun Card(modifier: Modifier = Modifier, padding: Int = 14, content: @Composable () -> Unit) {
    val c = LocalAppColors.current
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(c.card)
            .padding(padding.dp)
    ) { content() }
}

@Composable
fun DateNavBar(
    label: String,
    subLabel: String,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onLabelClick: () -> Unit,
) {
    val c = LocalAppColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(c.card)
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        RoundIconButton(Icons.Outlined.ChevronLeft, onPrev)
        Column(
            Modifier
                .weight(1f)
                .clickable { onLabelClick() },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(subLabel, fontSize = 11.5.sp, color = c.textSoft, fontWeight = FontWeight.SemiBold)
            Text(label, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = c.text)
        }
        RoundIconButton(Icons.Outlined.ChevronRight, onNext)
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, onClick: () -> Unit, tint: Color? = null) {
    val c = LocalAppColors.current
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(c.primaryLight)
    ) {
        Icon(icon, contentDescription = null, tint = tint ?: c.primaryDark)
    }
}

@Composable
fun CategoryCard(
    icon: ImageVector,
    name: String,
    totalText: String,
    hasSpend: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val c = LocalAppColors.current
    Column(
        modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(14.dp))
            .background(c.card)
            .border(1.5.dp, if (hasSpend) c.primaryLight else Color.Transparent, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = c.primaryDark, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Text(name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = c.text, textAlign = androidx.compose.ui.text.style.TextAlign.Center, maxLines = 2)
        Spacer(Modifier.height(3.dp))
        Text(totalText, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = if (hasSpend) c.primaryDark else c.textSoft)
    }
}

@Composable
fun ProgressCard(title: String, subText: String, pct: Float, danger: Boolean = false, warn: Boolean = false) {
    val c = LocalAppColors.current
    Card {
        Column {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = c.text)
                Text(subText, fontSize = 12.sp, color = c.textSoft, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(c.bg)
            ) {
                val color = if (danger) c.danger else if (warn) c.warning else c.primary
                Box(
                    Modifier
                        .fillMaxWidth(min(pct, 1f).coerceAtLeast(0f))
                        .height(10.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(color)
                )
            }
        }
    }
}

@Composable
fun BudgetAlertBanner(text: String, danger: Boolean) {
    val c = LocalAppColors.current
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (danger) Color(0xFFFEE2E2) else c.warningLight)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(text, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = if (danger) c.danger else Color(0xFF92400E))
    }
}

@Composable
fun BarRow(label: @Composable () -> Unit, pct: Float, valueText: String, color: Color) {
    val c = LocalAppColors.current
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(c.card)
    ) {
        Row(Modifier.fillMaxWidth().height(androidx.compose.ui.unit.IntrinsicSize.Min)) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(color))
            Column(Modifier.padding(10.dp).weight(1f)) {
                label()
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(c.bg)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(min(pct, 1f).coerceAtLeast(0f))
                            .height(7.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(color)
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(valueText, fontSize = 11.sp, color = c.textSoft, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun PieChart(values: List<Pair<String, Double>>, total: Double, modifier: Modifier = Modifier) {
    if (total <= 0 || values.isEmpty()) return
    val c = LocalAppColors.current
    Card {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Canvas(modifier = Modifier.size(100.dp)) {
                var startAngle = -90f
                val strokeWidth = size.minDimension * 0.16f
                values.forEachIndexed { idx, (_, v) ->
                    val sweep = (v / total * 360.0).toFloat()
                    drawArc(
                        color = ReportColors[idx % ReportColors.size],
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = false,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth)
                    )
                    startAngle += sweep
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                values.take(6).forEachIndexed { idx, (name, v) ->
                    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).clip(CircleShape).background(ReportColors[idx % ReportColors.size]))
                        Spacer(Modifier.width(6.dp))
                        Text(name, fontSize = 11.5.sp, color = c.text, modifier = Modifier.weight(1f), maxLines = 1)
                        Text("${((v / total) * 100).toInt()}%", fontSize = 11.sp, color = c.textSoft, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TagChip(text: String) {
    val c = LocalAppColors.current
    Box(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(c.primaryLight)
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text("#$text", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = c.primaryDark)
    }
}

@Composable
fun SectionLabel(text: String) {
    val c = LocalAppColors.current
    Text(text, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = c.textSoft, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
}
