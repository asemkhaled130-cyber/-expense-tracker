package com.example.expensetracker.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf

/** ألوان إضافية بمعنى شبيه بمتغيرات CSS (--bg, --card-bg, --text-soft, --border ...) */
data class AppColors(
    val bg: androidx.compose.ui.graphics.Color,
    val card: androidx.compose.ui.graphics.Color,
    val text: androidx.compose.ui.graphics.Color,
    val textSoft: androidx.compose.ui.graphics.Color,
    val border: androidx.compose.ui.graphics.Color,
    val primary: androidx.compose.ui.graphics.Color,
    val primaryDark: androidx.compose.ui.graphics.Color,
    val primaryLight: androidx.compose.ui.graphics.Color,
    val danger: androidx.compose.ui.graphics.Color,
    val warning: androidx.compose.ui.graphics.Color,
    val warningLight: androidx.compose.ui.graphics.Color,
)

val LocalAppColors = staticCompositionLocalOf {
    AppColors(BgLight, CardLight, TextLight, TextSoftLight, BorderLight, Primary, PrimaryDark, PrimaryLightLight, Danger, Warning, WarningLightLight)
}

@Composable
fun ExpenseTrackerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val appColors = if (darkTheme) {
        AppColors(BgDark, CardDark, TextDark, TextSoftDark, BorderDark, Primary, PrimaryDark, PrimaryLightDark, Danger, Warning, WarningLightDark)
    } else {
        AppColors(BgLight, CardLight, TextLight, TextSoftLight, BorderLight, Primary, PrimaryDark, PrimaryLightLight, Danger, Warning, WarningLightLight)
    }

    val colorScheme = if (darkTheme) {
        darkColorScheme(primary = Primary, secondary = PrimaryDark, background = BgDark, surface = CardDark, error = Danger)
    } else {
        lightColorScheme(primary = Primary, secondary = PrimaryDark, background = BgLight, surface = CardLight, error = Danger)
    }

    CompositionLocalProvider(LocalAppColors provides appColors) {
        MaterialTheme(colorScheme = colorScheme, typography = AppTypography, content = content)
    }
}
