package com.example.expensetracker.util

import android.accounts.Account
import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.extensions.android.http.AndroidHttp
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * نسخ احتياطي على Google Drive الخاص بالمستخدم فقط، في مساحة appDataFolder المخفية
 * (لا تظهر في Drive العادي ولا يصل لها إلا هذا التطبيق تحديدًا) — أقرب حل عملي لمزامنة يدوية بين الأجهزة.
 *
 * ملاحظة إعداد: يتطلب هذا مشروع Google Cloud خاص بالمطوّر (مفعّل فيه Drive API)
 * وربط بصمة SHA-1 لمفتاح التوقيع الخاص بالتطبيق. راجع README.
 */
object DriveBackupHelper {
    private const val BACKUP_FILE_NAME = "expense_tracker_backup.json"

    fun getSignInClient(context: Context): GoogleSignInClient {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestScopes(Scope(DriveScopes.DRIVE_APPDATA))
            .build()
        return GoogleSignIn.getClient(context, options)
    }

    fun getSignInIntent(context: Context): Intent = getSignInClient(context).signInIntent

    fun lastSignedInAccount(context: Context): GoogleSignInAccount? = GoogleSignIn.getLastSignedInAccount(context)

    private fun driveService(context: Context, account: Account): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(context, listOf(DriveScopes.DRIVE_APPDATA))
        credential.selectedAccount = account
        return Drive.Builder(AndroidHttp.newCompatibleTransport(), GsonFactory.getDefaultInstance(), credential)
            .setApplicationName("مصروفاتي")
            .build()
    }

    suspend fun backup(context: Context, account: GoogleSignInAccount, jsonContent: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val drive = driveService(context, account.account ?: return@withContext false)
                val existingId = findBackupFileId(drive)
                val content = com.google.api.client.http.ByteArrayContent("application/json", jsonContent.toByteArray())
                if (existingId != null) {
                    drive.files().update(existingId, null, content).execute()
                } else {
                    val meta = DriveFile().apply {
                        name = BACKUP_FILE_NAME
                        parents = listOf("appDataFolder")
                    }
                    drive.files().create(meta, content).execute()
                }
                true
            } catch (e: Exception) { false }
        }

    suspend fun restore(context: Context, account: GoogleSignInAccount): String? =
        withContext(Dispatchers.IO) {
            try {
                val drive = driveService(context, account.account ?: return@withContext null)
                val id = findBackupFileId(drive) ?: return@withContext null
                val out = ByteArrayOutputStream()
                drive.files().get(id).executeMediaAndDownloadTo(out)
                out.toString("UTF-8")
            } catch (e: Exception) { null }
        }

    private fun findBackupFileId(drive: Drive): String? {
        val result = drive.files().list()
            .setSpaces("appDataFolder")
            .setQ("name = '$BACKUP_FILE_NAME'")
            .setFields("files(id, name)")
            .execute()
        return result.files?.firstOrNull()?.id
    }
}
