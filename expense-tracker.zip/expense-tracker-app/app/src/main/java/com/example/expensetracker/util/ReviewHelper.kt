package com.example.expensetracker.util

import android.app.Activity
import android.content.Intent
import android.net.Uri
import com.google.android.play.core.review.ReviewManagerFactory

object ReviewHelper {
    /** يعرض حوار التقييم الرسمي داخل التطبيق مباشرة (بدون الخروج للمتجر) لو متاح، وإلا يفتح صفحة المتجر */
    fun requestReview(activity: Activity) {
        try {
            val manager = ReviewManagerFactory.create(activity)
            val request = manager.requestReviewFlow()
            request.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    manager.launchReviewFlow(activity, task.result)
                } else {
                    openStorePage(activity)
                }
            }
        } catch (e: Exception) {
            openStorePage(activity)
        }
    }

    fun openStorePage(activity: Activity) {
        val uri = Uri.parse("market://details?id=${activity.packageName}")
        try {
            activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            activity.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${activity.packageName}"))
            )
        }
    }
}
