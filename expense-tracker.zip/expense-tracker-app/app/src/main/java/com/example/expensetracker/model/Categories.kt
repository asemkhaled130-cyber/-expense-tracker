package com.example.expensetracker.model

import com.example.expensetracker.R

data class Category(
    val id: String,
    val nameRes: Int,
    val iconKey: String,
    val typesRes: List<Int> = emptyList(),
    val isIncome: Boolean = false,
    val isCustom: Boolean = false,
    val customName: String? = null // للتصنيفات المخصصة فقط
)

const val INCOME_CAT_ID = "__income__"

object Categories {
    val BUILTIN = listOf(
        Category("food", R.string.cat_food, "food", listOf(R.string.type_restaurant, R.string.type_cafe, R.string.type_groceries)),
        Category("transport", R.string.cat_transport, "transport", listOf(R.string.type_fuel, R.string.type_public_transport, R.string.type_taxi)),
        Category("bills", R.string.cat_bills, "bills", listOf(R.string.type_electricity, R.string.type_water, R.string.type_internet, R.string.type_mobile)),
        Category("clothes", R.string.cat_clothes, "clothes"),
        Category("shopping", R.string.cat_shopping, "shopping"),
        Category("health", R.string.cat_health, "health"),
        Category("fun", R.string.cat_fun, "fun"),
        Category("rent", R.string.cat_rent, "rent"),
        Category("misc", R.string.cat_misc, "misc"),
    )

    val INCOME = Category(
        INCOME_CAT_ID, R.string.cat_income, "income",
        listOf(R.string.income_salary, R.string.income_extra, R.string.income_gift, R.string.income_other),
        isIncome = true
    )

    val ICON_CHOICES = listOf("misc", "shopping", "health", "fun", "food", "bills", "clothes", "transport")
}
