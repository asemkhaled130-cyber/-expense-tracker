package com.example.expensetracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetracker.ui.components.BarRow
import com.example.expensetracker.ui.components.Card
import com.example.expensetracker.ui.components.PieChart
import com.example.expensetracker.ui.components.ProgressCard
import com.example.expensetracker.ui.components.RoundIconButton
import com.example.expensetracker.ui.icons.AppIcons
import com.example.expensetracker.ui.theme.LocalAppColors
import com.example.expensetracker.ui.theme.ReportColors
import com.example.expensetracker.util.Exporters
import com.example.expensetracker.util.monthName
import com.example.expensetracker.viewmodel.AppViewModel
import com.example.expensetracker.viewmodel.CategoryWithTotal
import java.time.LocalDate

@Composable
fun ReportsScreen(vm: AppViewModel) {
    val c = LocalAppColors.current
    val context = LocalContext.current
    val lang by vm.language.collectAsState()
    var mode by remember { mutableStateOf("week") }
    var anchor by remember { mutableStateOf(LocalDate.now()) }
    var result by remember { mutableStateOf<AppViewModel.ReportResult?>(null) }
    val budgets by vm.budgets.collectAsState()
    val savingsGoal by vm.savingsGoal.collectAsState()

    LaunchedEffect(mode, anchor, budgets) { result = vm.computeReport(mode, anchor) }

    val (from, to) = vm.periodRange(mode, anchor)
    val periodLabel = when (mode) {
        "week" -> "${from.dayOfMonth} ${monthName(from.monthValue, lang)} → ${to.dayOfMonth} ${monthName(to.monthValue, lang)}"
        "year" -> "${anchor.year}"
        else -> "${monthName(anchor.monthValue, lang)} ${anchor.year}"
    }
    val r = result

    LazyColumn(
        modifier = Modifier.fillMaxWidth().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.card).padding(5.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                listOf("week" to "أسبوعي", "month" to "شهري", "year" to "سنوي").forEach { (m, label) ->
                    val selected = mode == m
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                            .background(if (selected) c.primary else Color.Transparent)
                            .clickable { mode = m }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (selected) Color.White else c.textSoft)
                    }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.card).padding(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                RoundIconButton(AppIcons.ChevronLeft) { anchor = vm.shiftAnchor(mode, anchor, -1) }
                Text(periodLabel, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = c.textSoft, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                RoundIconButton(AppIcons.ChevronRight) { anchor = vm.shiftAnchor(mode, anchor, 1) }
            }
        }

        if (r != null) {
            item {
                Card {
                    Row(Modifier.fillMaxWidth()) {
                        BalanceCol("الدخل", vm.money(r.incomeTotal), Modifier.weight(1f), Color(0xFF059669))
                        BalanceCol("المصروفات", vm.money(r.expenseTotal), Modifier.weight(1f), c.danger, r.compareText)
                        BalanceCol("الصافي", vm.money(r.net), Modifier.weight(1f), c.primaryDark)
                    }
                }
            }
            if (mode == "month") {
                val overall = budgets.find { it.categoryId == "__overall__" }
                if (overall != null) {
                    item {
                        val pct = (r.expenseTotal / overall.amount).toFloat()
                        ProgressCard("الميزانية الشهرية", "${vm.money(r.expenseTotal)} / ${vm.money(overall.amount)}", pct, danger = r.expenseTotal > overall.amount, warn = pct >= 0.8f)
                    }
                }
                val goal = savingsGoal
                if (goal != null && goal > 0) {
                    item {
                        val pct = (r.net / goal).toFloat().coerceAtLeast(0f)
                        ProgressCard("هدف الادخار", "${vm.money(r.net.coerceAtLeast(0.0))} / ${vm.money(goal)}", pct)
                    }
                }
            }
            if (r.categoryTotals.isNotEmpty()) {
                item {
                    PieChart(r.categoryTotals.map { (it.category.customName ?: stringResource(it.category.nameRes)) to it.total }, r.expenseTotal)
                }
            }

            if (mode == "year") {
                items(r.monthlyTrend) { (label, total) ->
                    val max = r.monthlyTrend.maxOfOrNull { it.second }?.coerceAtLeast(1.0) ?: 1.0
                    BarRow(
                        label = { Text(monthName(label.toInt(), lang), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.text) },
                        pct = (total / max).toFloat(), valueText = if (total > 0) vm.money(total) else "-", color = c.primary
                    )
                }
            } else {
                itemsIndexed(r.categoryTotals) { idx, ct ->
                    val max = r.categoryTotals.maxOfOrNull { it.total }?.coerceAtLeast(1.0) ?: 1.0
                    BarRow(
                        label = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(AppIcons.forCategory(ct.category.iconKey), contentDescription = null, tint = ReportColors[idx % ReportColors.size], modifier = Modifier.height(16.dp))
                                Spacer(Modifier.padding(horizontal = 3.dp))
                                Text(ct.category.customName ?: stringResource(ct.category.nameRes), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.text)
                            }
                        },
                        pct = (ct.total / max).toFloat(), valueText = vm.money(ct.total), color = ReportColors[idx % ReportColors.size]
                    )
                }
            }

            item {
                Column {
                    Button(
                        onClick = {
                            val rows = listOf(listOf("القسم", "المبلغ")) + r.categoryTotals.map { listOf(it.category.customName ?: "", it.total.toString()) }
                            val file = Exporters.exportCsv(context, rows, "تقرير_$mode.csv")
                            Exporters.shareFile(context, file, "text/csv")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Icon(AppIcons.Chart, contentDescription = null); Text("  تصدير CSV لهذه الفترة") }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = {
                                val rows = listOf(listOf("القسم", "المبلغ")) + r.categoryTotals.map { listOf(it.category.customName ?: "", it.total.toString()) }
                                val file = Exporters.exportPdf(context, periodLabel, rows, "تقرير.pdf")
                                Exporters.shareFile(context, file, "application/pdf")
                            },
                            modifier = Modifier.weight(1f)
                        ) { Icon(AppIcons.Print, contentDescription = null); Text("  PDF") }
                        OutlinedButton(
                            onClick = {
                                val text = "ملخص $periodLabel\nالمصروفات: ${vm.money(r.expenseTotal)}\nالدخل: ${vm.money(r.incomeTotal)}\nالصافي: ${vm.money(r.net)}"
                                Exporters.shareText(context, text)
                            },
                            modifier = Modifier.weight(1f)
                        ) { Icon(AppIcons.Share, contentDescription = null); Text("  مشاركة") }
                    }
                    Spacer(Modifier.height(90.dp))
                }
            }
        }
    }
}

@Composable
private fun BalanceCol(label: String, value: String, modifier: Modifier, color: Color, compareText: String? = null) {
    val c = LocalAppColors.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 11.5.sp, color = c.textSoft, fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = color)
        if (compareText != null) Text(compareText, fontSize = 10.sp, color = c.textSoft, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}
