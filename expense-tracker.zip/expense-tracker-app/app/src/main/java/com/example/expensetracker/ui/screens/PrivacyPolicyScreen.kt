package com.example.expensetracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetracker.ui.icons.AppIcons
import com.example.expensetracker.ui.theme.LocalAppColors

@Composable
fun PrivacyPolicyScreen(onClose: () -> Unit) {
    val c = LocalAppColors.current
    Column(Modifier.fillMaxSize().background(c.bg)) {
        Row(
            Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(c.primary, c.primaryDark))).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(AppIcons.Close, contentDescription = null, tint = Color.White) }
            Text("سياسة الخصوصية", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
            Sec("مقدمة", "تطبيق \"مصروفاتي\" مصمم لمساعدتك على تسجيل ومتابعة مصروفاتك ودخلك الشخصي. كل بياناتك مخزّنة محليًا على جهازك فقط.")
            Sec("البيانات التي يجمعها التطبيق", "التطبيق لا يرسل أي بيانات إلى أي خادم خارجي تلقائيًا. كل ما تدخله (المصروفات، الدخل، الصور، الإعدادات، الرقم السري) يُخزَّن محليًا في قاعدة بيانات التطبيق على جهازك.")
            Sec("النسخ الاحتياطي على Google Drive (اختياري)", "لو فعّلت ميزة النسخ الاحتياطي على Google Drive، هيتم رفع نسخة من بياناتك (بدون الصور) إلى مساحة خاصة بالتطبيق داخل Drive حسابك الشخصي فقط، ومش بتظهر لأي طرف تاني ولا حتى في واجهة Drive العادية.")
            Sec("الصور", "صور الفواتير تُحفظ داخل تخزين التطبيق على جهازك فقط، ولا تُرفع لأي مكان.")
            Sec("الأذونات المطلوبة", "الكاميرا: لالتقاط صورة الفاتورة فقط. الميكروفون: للإدخال الصوتي فقط عند طلبك ذلك. الإشعارات: لتذكيرك يوميًا لو فعّلت هذه الميزة.")
            Sec("حذف البيانات", "يمكنك حذف كل بياناتك من داخل التطبيق (الإعدادات ← حذف كل البيانات)، أو بحذف التطبيق نفسه من جهازك.")
        }
    }
}

@Composable
private fun Sec(title: String, body: String) {
    val c = LocalAppColors.current
    Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = c.primaryDark, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
    Text(body, fontSize = 13.sp, color = c.text, lineHeight = 20.sp)
}
