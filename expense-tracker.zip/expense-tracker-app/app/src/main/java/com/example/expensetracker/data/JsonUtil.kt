package com.example.expensetracker.data

import org.json.JSONArray
import org.json.JSONObject

/** أدوات تحويل خفيفة تعتمد على org.json المدمجة في أندرويد، لتفادي إضافة مكتبة JSON خارجية. */
object JsonUtil {

    fun itemsToJson(items: List<ItemLine>): String {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("name", it.name).put("price", it.price)) }
        return arr.toString()
    }

    fun itemsFromJson(json: String?): List<ItemLine> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                ItemLine(o.optString("name"), o.optDouble("price", 0.0))
            }
        } catch (e: Exception) { emptyList() }
    }

    fun stringsToJson(list: List<String>): String {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return arr.toString()
    }

    fun stringsFromJson(json: String?): List<String> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) { emptyList() }
    }
}
