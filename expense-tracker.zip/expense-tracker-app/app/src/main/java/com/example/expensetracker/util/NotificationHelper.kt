package com.example.expensetracker.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.CoroutineWorker
import com.example.expensetracker.MainActivity
import com.example.expensetracker.R
import com.example.expensetracker.data.AppDatabase
import com.example.expensetracker.data.SettingsRepository
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit

const val REMINDER_CHANNEL_ID = "daily_reminder"
private const val REMINDER_WORK_NAME = "daily_reminder_work"

object NotificationHelper {

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                REMINDER_CHANNEL_ID, "تذكير المصروفات", NotificationManager.IMPORTANCE_DEFAULT
            )
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    fun scheduleDaily(context: Context, hour: Int, minute: Int) {
        ensureChannel(context)
        val now = LocalDateTime.now()
        var target = LocalDateTime.of(LocalDate.now(), LocalTime.of(hour, minute))
        if (target.isBefore(now)) target = target.plusDays(1)
        val delay = java.time.Duration.between(now, target).toMillis()

        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setConstraints(Constraints.Builder().build())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(REMINDER_WORK_NAME, ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(REMINDER_WORK_NAME)
    }
}

/** يفحص هل المستخدم سجّل النهاردة، ولو لأ يبعتله إشعار، وبعدين يعيد جدولة نفسه لبكرة */
class ReminderWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val context = applicationContext
        val settings = SettingsRepository(context)
        val enabled = settings.reminderEnabled.first()
        if (enabled) {
            val db = AppDatabase.getInstance(context)
            val today = LocalDate.now().format(java.time.format.DateTimeFormatter.ISO_LOCAL_DATE)
            val hasEntry = db.expenseDao().getByRange(today, today).isNotEmpty() ||
                db.incomeDao().getByRange(today, today).isNotEmpty()
            if (!hasEntry) sendNotification(context)
            val hour = settings.reminderHour.first()
            val minute = settings.reminderMinute.first()
            NotificationHelper.scheduleDaily(context, hour, minute)
        }
        return Result.success()
    }

    private fun sendNotification(context: Context) {
        val openIntent = android.content.Intent(context, MainActivity::class.java)
        val pending = android.app.PendingIntent.getActivity(
            context, 0, openIntent,
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(context, REMINDER_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.daily_reminder_label))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < 33
        ) {
            NotificationManagerCompat.from(context).notify(1001, notif)
        }
    }
}
