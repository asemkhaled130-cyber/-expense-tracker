package com.example.expensetracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetracker.data.ExpenseEntity
import com.example.expensetracker.data.IncomeEntity
import com.example.expensetracker.data.JsonUtil
import com.example.expensetracker.model.Categories
import com.example.expensetracker.model.Category
import com.example.expensetracker.ui.components.BudgetAlertBanner
import com.example.expensetracker.ui.components.CategoryCard
import com.example.expensetracker.ui.components.DateNavBar
import com.example.expensetracker.ui.icons.AppIcons
import com.example.expensetracker.ui.theme.LocalAppColors
import com.example.expensetracker.util.formatDateShort
import com.example.expensetracker.util.parseDate
import com.example.expensetracker.util.todayStr
import com.example.expensetracker.util.weekdayName
import com.example.expensetracker.viewmodel.AppViewModel
import com.example.expensetracker.viewmodel.CategoryWithTotal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(vm: AppViewModel, lang: String) {
    val c = LocalAppColors.current
    val date by vm.registerDate.collectAsState()
    val totals = vm.registerCategoryTotals()
    val incomeTotal = vm.registerIncomeTotal()
    val dayTotal = vm.registerDayTotal()
    val alerts by vm.budgetAlerts.collectAsState()

    var openCategory by remember { mutableStateOf<Category?>(null) }
    var openIncome by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        val d = parseDate(date)
        DateNavBar(
            label = formatDateShort(d, lang),
            subLabel = weekdayName(d, lang),
            onPrev = { vm.shiftRegisterDate(-1) },
            onNext = { vm.shiftRegisterDate(1) },
            onLabelClick = { }
        )
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (date == todayStr()) {
                Text(
                    "اليوم", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = c.primaryDark,
                    modifier = Modifier.background(c.primaryLight, RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 3.dp)
                )
            } else {
                Text(
                    "الرجوع لليوم", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = c.primaryDark,
                    modifier = Modifier.clickable { vm.setRegisterDate(todayStr()) }.padding(4.dp)
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        if (alerts.isNotEmpty()) {
            val a = alerts.find { it.isDanger } ?: alerts.first()
            BudgetAlertBanner(a.text, a.isDanger)
            Spacer(Modifier.height(8.dp))
        }

        Text(
            "إجمالي اليوم: ${vm.money(dayTotal)}", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = c.primaryDark,
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), textAlign = TextAlign.Center
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 90.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(totals) { ct: CategoryWithTotal ->
                CategoryCard(
                    icon = AppIcons.forCategory(ct.category.iconKey),
                    name = ct.category.customName ?: stringResource(ct.category.nameRes),
                    totalText = if (ct.total > 0) vm.money(ct.total) else "—",
                    hasSpend = ct.total > 0,
                    onClick = { openCategory = ct.category }
                )
            }
            item {
                CategoryCard(
                    icon = AppIcons.forCategory("income"),
                    name = stringResource(Categories.INCOME.nameRes),
                    totalText = if (incomeTotal > 0) vm.money(incomeTotal) else "—",
                    hasSpend = incomeTotal > 0,
                    onClick = { openIncome = true }
                )
            }
        }
    }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    if (openCategory != null) {
        val cat = openCategory!!
        ModalBottomSheet(onDismissRequest = { openCategory = null }, sheetState = sheetState) {
            CategoryEntriesSheet(vm = vm, category = cat, date = date, onClose = { openCategory = null })
        }
    }
    if (openIncome) {
        ModalBottomSheet(onDismissRequest = { openIncome = false }, sheetState = sheetState) {
            CategoryEntriesSheet(vm = vm, category = Categories.INCOME, date = date, onClose = { openIncome = false })
        }
    }
}

/** يعرض العمليات المسجلة لقسم/دخل في يوم معيّن، وزر إضافة يفتح EntryFormSheet */
@Composable
fun CategoryEntriesSheet(vm: AppViewModel, category: Category, date: String, onClose: () -> Unit) {
    val c = LocalAppColors.current
    val expenses by vm.registerExpenses.collectAsState()
    val income by vm.registerIncome.collectAsState()
    val wallets by vm.wallets.collectAsState()
    val currencies by vm.currencies.collectAsState()

    var showAddForm by remember { mutableStateOf(false) }
    var editingExpense by remember { mutableStateOf<ExpenseEntity?>(null) }
    var editingIncome by remember { mutableStateOf<IncomeEntity?>(null) }

    val list: List<Any> = if (category.isIncome) income else expenses.filter { it.categoryId == category.id }

    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(category.customName ?: stringResource(category.nameRes), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = c.text)
            IconButton(onClick = onClose) { Icon(AppIcons.Close, contentDescription = null) }
        }
        Spacer(Modifier.height(8.dp))

        if (!showAddForm && editingExpense == null && editingIncome == null) {
            if (list.isEmpty()) {
                Text("لا يوجد سجل بعد", color = c.textSoft, fontSize = 13.sp, modifier = Modifier.padding(vertical = 12.dp))
            } else {
                list.forEach { entry ->
                    EntrySummaryRow(
                        vm = vm, entry = entry,
                        onEdit = {
                            if (entry is ExpenseEntity) editingExpense = entry
                            if (entry is IncomeEntity) editingIncome = entry
                        },
                        onDelete = {
                            if (entry is ExpenseEntity) vm.deleteExpenseEntry(entry)
                            if (entry is IncomeEntity) vm.deleteIncomeEntry(entry)
                        }
                    )
                }
            }
            Button(onClick = { showAddForm = true }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Icon(AppIcons.Add, contentDescription = null)
                Text("  " + (if (category.isIncome) "إضافة دخل جديد" else "إضافة عملية جديدة"))
            }
        } else {
            val existing = editingExpense
            val existingInc = editingIncome
            EntryFormSheet(
                category = category,
                existingType = existing?.type ?: existingInc?.type ?: "",
                existingItems = existing?.let { JsonUtil.itemsFromJson(it.itemsJson) } ?: emptyList(),
                existingAmount = existing?.origAmount ?: existing?.amount ?: existingInc?.origAmount ?: existingInc?.amount ?: 0.0,
                existingNote = existing?.note ?: existingInc?.note ?: "",
                existingTags = existing?.let { JsonUtil.stringsFromJson(it.tagsJson) }
                    ?: existingInc?.let { JsonUtil.stringsFromJson(it.tagsJson) } ?: emptyList(),
                existingWallet = existing?.walletId ?: existingInc?.walletId,
                existingCurrency = existing?.origCurrency ?: existingInc?.origCurrency,
                existingSplit = existing?.splitCount,
                existingImages = existing?.let { JsonUtil.stringsFromJson(it.imagesJson) }
                    ?: existingInc?.let { JsonUtil.stringsFromJson(it.imagesJson) } ?: emptyList(),
                wallets = wallets, currencies = currencies,
                checkAnomaly = { amount -> vm.checkAnomaly(category.id, amount) },
                onSave = { result ->
                    val rate = currencies.find { it.code == result.currencyCode }?.rate ?: 1.0
                    val baseAmount = result.amount * rate
                    if (category.isIncome) {
                        vm.saveIncomeEntry(
                            IncomeEntity(
                                id = existingInc?.id ?: vm.repo.newId(), date = date, type = result.type,
                                amount = baseAmount, note = result.note,
                                tagsJson = JsonUtil.stringsToJson(result.tags),
                                imagesJson = JsonUtil.stringsToJson(result.images),
                                walletId = result.walletId, origCurrency = result.currencyCode,
                                origAmount = if (result.currencyCode != null) result.amount else null,
                                createdAt = existingInc?.createdAt ?: System.currentTimeMillis()
                            )
                        )
                    } else {
                        vm.saveExpenseEntry(
                            ExpenseEntity(
                                id = existing?.id ?: vm.repo.newId(), date = date, categoryId = category.id, type = result.type,
                                itemsJson = JsonUtil.itemsToJson(result.items),
                                amount = baseAmount, note = result.note,
                                tagsJson = JsonUtil.stringsToJson(result.tags),
                                imagesJson = JsonUtil.stringsToJson(result.images),
                                walletId = result.walletId, origCurrency = result.currencyCode,
                                origAmount = if (result.currencyCode != null) result.amount else null,
                                splitCount = result.splitCount, recurringId = existing?.recurringId,
                                createdAt = existing?.createdAt ?: System.currentTimeMillis()
                            )
                        )
                    }
                    showAddForm = false; editingExpense = null; editingIncome = null
                },
                onCancel = { showAddForm = false; editingExpense = null; editingIncome = null }
            )
        }
    }
}

data class EntryDisplay(val type: String, val amount: Double, val note: String, val tags: List<String>, val splitCount: Int?)

@Composable
fun EntrySummaryRow(vm: AppViewModel, entry: Any, onEdit: () -> Unit, onDelete: () -> Unit) {
    val c = LocalAppColors.current
    val display = when (entry) {
        is ExpenseEntity -> EntryDisplay(entry.type, entry.amount, entry.note, JsonUtil.stringsFromJson(entry.tagsJson), entry.splitCount)
        is IncomeEntity -> EntryDisplay(entry.type, entry.amount, entry.note, JsonUtil.stringsFromJson(entry.tagsJson), null)
        else -> EntryDisplay("", 0.0, "", emptyList(), null)
    }
    Box(
        Modifier.fillMaxWidth().padding(vertical = 5.dp)
            .background(c.bg, RoundedCornerShape(10.dp)).padding(10.dp)
    ) {
        Column {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(display.type.ifBlank { "بدون عنوان" }, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = c.text)
                Text(vm.money(display.amount), fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = c.primaryDark)
            }
            if (display.note.isNotBlank()) Text(display.note, fontSize = 11.5.sp, color = c.textSoft, modifier = Modifier.padding(top = 4.dp))
            if (display.splitCount != null && display.splitCount > 1) {
                Text(
                    "مقسومة على ${display.splitCount} — نصيبك: ${vm.money(display.amount / display.splitCount)}",
                    fontSize = 11.sp, color = c.primaryDark, modifier = Modifier.padding(top = 4.dp)
                )
            }
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("تعديل", fontSize = 12.sp, color = c.primaryDark, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onEdit() })
                Text("حذف", fontSize = 12.sp, color = c.danger, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onDelete() })
            }
        }
    }
}
