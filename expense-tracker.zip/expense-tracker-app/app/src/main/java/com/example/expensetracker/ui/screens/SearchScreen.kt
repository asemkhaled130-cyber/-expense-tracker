package com.example.expensetracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetracker.model.Categories
import com.example.expensetracker.ui.icons.AppIcons
import com.example.expensetracker.ui.theme.LocalAppColors
import com.example.expensetracker.util.formatDateShort
import com.example.expensetracker.util.parseDate
import com.example.expensetracker.viewmodel.AppViewModel

@Composable
fun SearchScreen(vm: AppViewModel, onClose: () -> Unit, onOpenResult: (date: String, categoryId: String) -> Unit) {
    val c = LocalAppColors.current
    val lang by vm.language.collectAsState()
    val categories by vm.categories.collectAsState()
    val allCats = remember(categories) { listOf(Categories.INCOME) + categories }

    var text by remember { mutableStateOf("") }
    var minAmount by remember { mutableStateOf("") }
    var maxAmount by remember { mutableStateOf("") }
    var activeCats by remember { mutableStateOf(setOf<String>()) }
    var results by remember { mutableStateOf<List<AppViewModel.SearchResult>>(emptyList()) }

    LaunchedEffect(text, minAmount, maxAmount, activeCats) {
        results = vm.search(text, null, null, minAmount.toDoubleOrNull(), maxAmount.toDoubleOrNull(), activeCats)
    }

    Column(Modifier.fillMaxSize().background(c.bg)) {
        Row(
            Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(c.primary, c.primaryDark)))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(AppIcons.Close, contentDescription = null, tint = Color.White) }
            Text("البحث والفلترة", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Column(Modifier.fillMaxSize().padding(14.dp)) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ابحث في الوصف أو الملاحظات أو الوسوم…") }
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = minAmount, onValueChange = { minAmount = it }, modifier = Modifier.weight(1f), placeholder = { Text("أقل مبلغ") })
                OutlinedTextField(value = maxAmount, onValueChange = { maxAmount = it }, modifier = Modifier.weight(1f), placeholder = { Text("أعلى مبلغ") })
            }
            Spacer(Modifier.height(8.dp))
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(allCats) { cat ->
                    val selected = cat.id in activeCats
                    val name = cat.customName ?: stringResource(cat.nameRes)
                    Text(
                        name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        color = if (selected) Color.White else c.textSoft,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (selected) c.primary else c.card)
                            .clickable { activeCats = if (selected) activeCats - cat.id else activeCats + cat.id }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            if (results.isEmpty()) {
                Text("مفيش نتائج مطابقة", color = c.textSoft, fontSize = 13.sp, modifier = Modifier.padding(top = 20.dp))
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 90.dp)) {
                    items(results.take(200)) { res ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.card)
                                .clickable { onOpenResult(res.date, res.category.id) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(AppIcons.forCategory(res.category.iconKey), contentDescription = null, tint = c.primaryDark, modifier = Modifier.height(24.dp))
                            Spacer(Modifier.padding(horizontal = 4.dp))
                            Column(Modifier.weight(1f)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(res.title.ifBlank { res.category.customName ?: stringResource(res.category.nameRes) }, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.text)
                                    Text(vm.money(res.amount), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = c.primaryDark)
                                }
                                Text(
                                    formatDateShort(parseDate(res.date), lang) + if (res.note.isNotBlank()) " · ${res.note}" else "",
                                    fontSize = 11.sp, color = c.textSoft, maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
