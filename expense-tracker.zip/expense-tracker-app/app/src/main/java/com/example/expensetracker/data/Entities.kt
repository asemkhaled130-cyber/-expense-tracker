package com.example.expensetracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

data class ItemLine(val name: String, val price: Double)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey val id: String,
    val date: String,            // YYYY-MM-DD
    val categoryId: String,
    val type: String,
    val itemsJson: String,       // [{"name":"..","price":..}, ...]
    val amount: Double,          // بعملة الأساس دائمًا
    val note: String,
    val tagsJson: String,        // ["tag1","tag2"]
    val imagesJson: String,      // ["file:///...","file:///..."]
    val walletId: String?,
    val origCurrency: String?,
    val origAmount: Double?,
    val splitCount: Int?,
    val recurringId: String?,
    val createdAt: Long
)

@Entity(tableName = "income")
data class IncomeEntity(
    @PrimaryKey val id: String,
    val date: String,
    val type: String,            // مصدر الدخل
    val amount: Double,
    val note: String,
    val tagsJson: String,
    val imagesJson: String,
    val walletId: String?,
    val origCurrency: String?,
    val origAmount: Double?,
    val createdAt: Long
)

@Entity(tableName = "custom_categories")
data class CategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val iconKey: String,
    val typesJson: String // [] عادة
)

@Entity(tableName = "wallets")
data class WalletEntity(
    @PrimaryKey val id: String,
    val name: String
)

@Entity(tableName = "currencies")
data class CurrencyEntity(
    @PrimaryKey val code: String,
    val rate: Double // قيمة الوحدة الواحدة بعملة الأساس
)

@Entity(tableName = "recurring")
data class RecurringEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    val title: String,
    val amount: Double,
    val day: Int,
    val lastAppliedMonth: String? // "YYYY-MM"
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val categoryId: String, // "__overall__" للميزانية العامة
    val amount: Double
)
