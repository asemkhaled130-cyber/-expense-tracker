package com.example.expensetracker.data

import com.example.expensetracker.model.Categories
import com.example.expensetracker.model.Category
import com.example.expensetracker.model.INCOME_CAT_ID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.UUID

val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE

class Repository(private val db: AppDatabase, val settings: SettingsRepository) {
    val expenseDao = db.expenseDao()
    val incomeDao = db.incomeDao()
    val categoryDao = db.categoryDao()
    val walletDao = db.walletDao()
    val currencyDao = db.currencyDao()
    val recurringDao = db.recurringDao()
    val budgetDao = db.budgetDao()

    fun newId(): String = UUID.randomUUID().toString()

    /** كل التصنيفات: الأساسية + المخصصة اللي المستخدم ضافها */
    fun allCategoriesFlow(): Flow<List<Category>> =
        categoryDao.observeAll().map { customs ->
            Categories.BUILTIN + customs.map {
                Category(it.id, 0, it.iconKey, emptyList(), isCustom = true, customName = it.name)
            }
        }

    suspend fun allCategoriesOnce(): List<Category> {
        val customs = categoryDao.getAllOnce()
        return Categories.BUILTIN + customs.map {
            Category(it.id, 0, it.iconKey, emptyList(), isCustom = true, customName = it.name)
        }
    }

    suspend fun findCategory(id: String): Category? {
        if (id == INCOME_CAT_ID) return Categories.INCOME
        return allCategoriesOnce().find { it.id == id }
    }

    // ---------- مصروفات ----------
    fun expensesForDate(date: String): Flow<List<ExpenseEntity>> = expenseDao.observeByDate(date)
    suspend fun saveExpense(e: ExpenseEntity) = expenseDao.upsert(e)
    suspend fun deleteExpense(id: String) = expenseDao.deleteById(id)

    suspend fun dayExpenseTotal(date: String): Double = expenseDao.getByRange(date, date).sumOf { it.amount }
    suspend fun dayIncomeTotal(date: String): Double = incomeDao.getByRange(date, date).sumOf { it.amount }

    suspend fun rangeExpenses(from: String, to: String): List<ExpenseEntity> = expenseDao.getByRange(from, to)
    suspend fun rangeIncome(from: String, to: String): List<IncomeEntity> = incomeDao.getByRange(from, to)

    suspend fun monthSpend(catId: String?, ym: YearMonth): Double {
        val from = ym.atDay(1).format(DATE_FMT)
        val to = ym.atEndOfMonth().format(DATE_FMT)
        val list = expenseDao.getByRange(from, to)
        return if (catId == null) list.sumOf { it.amount } else list.filter { it.categoryId == catId }.sumOf { it.amount }
    }

    // ---------- دخل ----------
    fun incomeForDate(date: String): Flow<List<IncomeEntity>> = incomeDao.observeByDate(date)
    suspend fun saveIncome(e: IncomeEntity) = incomeDao.upsert(e)
    suspend fun deleteIncome(id: String) = incomeDao.deleteById(id)

    // ---------- محافظ / عملات ----------
    fun walletsFlow(): Flow<List<WalletEntity>> = walletDao.observeAll()
    suspend fun ensureDefaultWallet() {
        if (walletDao.getAllOnce().isEmpty()) walletDao.upsert(WalletEntity("main", "المحفظة الرئيسية"))
    }
    fun currenciesFlow(): Flow<List<CurrencyEntity>> = currencyDao.observeAll()

    // ---------- ميزانية ----------
    fun budgetsFlow(): Flow<List<BudgetEntity>> = budgetDao.observeAll()

    // ---------- متكررة ----------
    fun recurringFlow(): Flow<List<RecurringEntity>> = recurringDao.observeAll()

    suspend fun applyRecurring() {
        val today = LocalDate.now()
        val ym = "%04d-%02d".format(today.year, today.monthValue)
        val list = recurringDao.getAllOnce()
        list.forEach { r ->
            if (r.lastAppliedMonth != ym && today.dayOfMonth >= r.day) {
                val day = minOf(r.day, today.lengthOfMonth())
                val dateStr = "%s-%02d".format(ym, day)
                expenseDao.upsert(
                    ExpenseEntity(
                        id = newId(), date = dateStr, categoryId = r.categoryId, type = r.title,
                        itemsJson = "[]", amount = r.amount, note = "مصروف متكرر تلقائي",
                        tagsJson = "[]", imagesJson = "[]", walletId = null,
                        origCurrency = null, origAmount = null, splitCount = null,
                        recurringId = r.id, createdAt = System.currentTimeMillis()
                    )
                )
                recurringDao.upsert(r.copy(lastAppliedMonth = ym))
            }
        }
    }

    // ---------- تصدير / نسخ احتياطي ----------
    suspend fun exportAllRows(): List<List<String>> {
        val header = listOf("التاريخ", "النوع", "القسم", "النوع/العنوان", "تفاصيل المشتريات", "المبلغ", "ملاحظات")
        val rows = mutableListOf(header)
        val cats = allCategoriesOnce().associateBy { it.id }
        expenseDao.getAll().sortedBy { it.date }.forEach { e ->
            val catName = cats[e.categoryId]?.customName ?: e.categoryId
            val items = JsonUtil.itemsFromJson(e.itemsJson).joinToString(" | ") { "${it.name}: ${it.price}" }
            rows.add(listOf(e.date, "مصروف", catName, e.type, items, e.amount.toString(), e.note))
        }
        incomeDao.getAll().sortedBy { it.date }.forEach { i ->
            rows.add(listOf(i.date, "دخل", "دخل", i.type, "", i.amount.toString(), i.note))
        }
        return rows
    }

    /** نسخة احتياطية كاملة بصيغة JSON (تُستخدم للنسخ المحلي وGoogle Drive أيضًا) */
    suspend fun exportBackupJson(): String {
        val root = org.json.JSONObject()
        val expArr = org.json.JSONArray()
        expenseDao.getAll().forEach { e ->
            expArr.put(
                org.json.JSONObject().apply {
                    put("id", e.id); put("date", e.date); put("categoryId", e.categoryId); put("type", e.type)
                    put("itemsJson", e.itemsJson); put("amount", e.amount); put("note", e.note)
                    put("tagsJson", e.tagsJson); put("imagesJson", "[]") // الصور محلية بالجهاز، لا تُنسخ في JSON
                    put("walletId", e.walletId ?: ""); put("origCurrency", e.origCurrency ?: "")
                    put("origAmount", e.origAmount ?: -1.0); put("splitCount", e.splitCount ?: -1)
                    put("recurringId", e.recurringId ?: ""); put("createdAt", e.createdAt)
                }
            )
        }
        val incArr = org.json.JSONArray()
        incomeDao.getAll().forEach { i ->
            incArr.put(
                org.json.JSONObject().apply {
                    put("id", i.id); put("date", i.date); put("type", i.type); put("amount", i.amount); put("note", i.note)
                    put("tagsJson", i.tagsJson); put("imagesJson", "[]")
                    put("walletId", i.walletId ?: ""); put("origCurrency", i.origCurrency ?: "")
                    put("origAmount", i.origAmount ?: -1.0); put("createdAt", i.createdAt)
                }
            )
        }
        val catArr = org.json.JSONArray()
        categoryDao.getAllOnce().forEach { c -> catArr.put(org.json.JSONObject().apply { put("id", c.id); put("name", c.name); put("iconKey", c.iconKey); put("typesJson", c.typesJson) }) }
        val walletArr = org.json.JSONArray()
        walletDao.getAllOnce().forEach { w -> walletArr.put(org.json.JSONObject().apply { put("id", w.id); put("name", w.name) }) }
        val currArr = org.json.JSONArray()
        currencyDao.getAllOnce().forEach { cur -> currArr.put(org.json.JSONObject().apply { put("code", cur.code); put("rate", cur.rate) }) }
        val recArr = org.json.JSONArray()
        recurringDao.getAllOnce().forEach { r -> recArr.put(org.json.JSONObject().apply { put("id", r.id); put("categoryId", r.categoryId); put("title", r.title); put("amount", r.amount); put("day", r.day); put("lastAppliedMonth", r.lastAppliedMonth ?: "") }) }
        val budArr = org.json.JSONArray()
        budgetDao.getAllOnce().forEach { b -> budArr.put(org.json.JSONObject().apply { put("categoryId", b.categoryId); put("amount", b.amount) }) }

        root.put("expenses", expArr); root.put("income", incArr); root.put("categories", catArr)
        root.put("wallets", walletArr); root.put("currencies", currArr); root.put("recurring", recArr); root.put("budgets", budArr)
        root.put("exportedAt", System.currentTimeMillis())
        return root.toString()
    }

    /** استعادة نسخة احتياطية JSON (تستبدل كل البيانات الحالية) */
    suspend fun importBackupJson(json: String): Boolean {
        return try {
            val root = org.json.JSONObject(json)
            expenseDao.deleteAll(); incomeDao.deleteAll(); budgetDao.deleteAll()

            val expArr = root.optJSONArray("expenses") ?: org.json.JSONArray()
            for (i in 0 until expArr.length()) {
                val o = expArr.getJSONObject(i)
                expenseDao.upsert(
                    ExpenseEntity(
                        id = o.getString("id"), date = o.getString("date"), categoryId = o.getString("categoryId"), type = o.optString("type"),
                        itemsJson = o.optString("itemsJson", "[]"), amount = o.optDouble("amount", 0.0), note = o.optString("note"),
                        tagsJson = o.optString("tagsJson", "[]"), imagesJson = "[]",
                        walletId = o.optString("walletId").ifBlank { null }, origCurrency = o.optString("origCurrency").ifBlank { null },
                        origAmount = o.optDouble("origAmount", -1.0).let { if (it < 0) null else it },
                        splitCount = o.optInt("splitCount", -1).let { if (it < 0) null else it },
                        recurringId = o.optString("recurringId").ifBlank { null }, createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
            val incArr = root.optJSONArray("income") ?: org.json.JSONArray()
            for (i in 0 until incArr.length()) {
                val o = incArr.getJSONObject(i)
                incomeDao.upsert(
                    IncomeEntity(
                        id = o.getString("id"), date = o.getString("date"), type = o.optString("type"),
                        amount = o.optDouble("amount", 0.0), note = o.optString("note"), tagsJson = o.optString("tagsJson", "[]"), imagesJson = "[]",
                        walletId = o.optString("walletId").ifBlank { null }, origCurrency = o.optString("origCurrency").ifBlank { null },
                        origAmount = o.optDouble("origAmount", -1.0).let { if (it < 0) null else it },
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
            val catArr = root.optJSONArray("categories") ?: org.json.JSONArray()
            for (i in 0 until catArr.length()) {
                val o = catArr.getJSONObject(i)
                categoryDao.upsert(CategoryEntity(o.getString("id"), o.optString("name"), o.optString("iconKey", "misc"), o.optString("typesJson", "[]")))
            }
            val walletArr = root.optJSONArray("wallets") ?: org.json.JSONArray()
            for (i in 0 until walletArr.length()) {
                val o = walletArr.getJSONObject(i)
                walletDao.upsert(WalletEntity(o.getString("id"), o.optString("name")))
            }
            val currArr = root.optJSONArray("currencies") ?: org.json.JSONArray()
            for (i in 0 until currArr.length()) {
                val o = currArr.getJSONObject(i)
                currencyDao.upsert(CurrencyEntity(o.getString("code"), o.optDouble("rate", 1.0)))
            }
            val recArr = root.optJSONArray("recurring") ?: org.json.JSONArray()
            for (i in 0 until recArr.length()) {
                val o = recArr.getJSONObject(i)
                recurringDao.upsert(RecurringEntity(o.getString("id"), o.getString("categoryId"), o.optString("title"), o.optDouble("amount", 0.0), o.optInt("day", 1), o.optString("lastAppliedMonth").ifBlank { null }))
            }
            val budArr = root.optJSONArray("budgets") ?: org.json.JSONArray()
            for (i in 0 until budArr.length()) {
                val o = budArr.getJSONObject(i)
                budgetDao.upsert(BudgetEntity(o.getString("categoryId"), o.optDouble("amount", 0.0)))
            }
            true
        } catch (e: Exception) { false }
    }
}
