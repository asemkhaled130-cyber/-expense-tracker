# احتفظ بأسماء كلاسات Room والبيانات لتفادي مشاكل الانعكاس (reflection)
-keep class com.example.expensetracker.data.** { *; }
-keepattributes *Annotation*
